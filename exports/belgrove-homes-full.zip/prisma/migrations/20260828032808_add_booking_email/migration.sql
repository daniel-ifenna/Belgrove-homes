/*
  Warnings:

  - Added the required column `email` to the `InspectionBooking` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "InspectionBooking" ADD COLUMN     "email" TEXT NOT NULL;
