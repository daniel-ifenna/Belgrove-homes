function layout(title: string, bodyHtml: string): string {
  return `
  <div style="font-family: Georgia, 'Times New Roman', serif; max-width: 560px; margin: 0 auto; color: #2b2620;">
    <div style="background: #3a3226; padding: 24px 32px;">
      <span style="color: #f5ece1; font-size: 20px; letter-spacing: 0.05em;">BELGROVE HOMES</span>
    </div>
    <div style="padding: 32px; background: #fdfbf7;">
      <h1 style="font-size: 20px; margin: 0 0 16px;">${title}</h1>
      ${bodyHtml}
    </div>
    <div style="padding: 16px 32px; background: #efe8dc; font-size: 12px; color: #6b6055;">
      Belgrove Homes &middot; This is an automated message regarding your inspection booking.
    </div>
  </div>`;
}

function fmtDate(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

export function bookingReceivedTemplate(params: {
  name: string;
  ref: string;
  preferredDate: Date | string;
  preferredTime: string;
  location: string;
  phone?: string | null;
}): string {
  const { name, ref, preferredDate, preferredTime, location, phone } = params;
  return layout(
    "We've received your inspection request",
    `
    <p>Hi ${name},</p>
    <p>Thank you for booking a property inspection with Belgrove Homes. Here's what you submitted:</p>
    <table style="width:100%; border-collapse: collapse; margin: 16px 0;">
      <tr><td style="padding:6px 0; color:#6b6055;">Reference</td><td style="padding:6px 0; font-weight:bold;">${ref}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Requested date</td><td style="padding:6px 0;">${fmtDate(preferredDate)}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Requested time</td><td style="padding:6px 0;">${preferredTime}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Location</td><td style="padding:6px 0;">${location}</td></tr>
      ${phone ? `<tr><td style="padding:6px 0; color:#6b6055;">Phone</td><td style="padding:6px 0;">${phone}</td></tr>` : ""}
    </table>
    <p>Keep your reference code <strong>${ref}</strong> handy — an agent will follow up shortly to confirm.</p>
    `
  );
}

export function adminNewBookingAlertTemplate(params: {
  name: string;
  ref: string;
  preferredDate: Date | string;
  preferredTime: string;
  location: string;
  agentName?: string | null;
  phone?: string | null;
  email?: string | null;
}): string {
  const { name, ref, preferredDate, preferredTime, location, agentName, phone, email } = params;
  return layout(
    "New inspection booking submitted",
    `
    <table style="width:100%; border-collapse: collapse; margin: 16px 0;">
      <tr><td style="padding:6px 0; color:#6b6055;">Reference</td><td style="padding:6px 0; font-weight:bold;">${ref}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Visitor</td><td style="padding:6px 0;">${name}</td></tr>
      ${email ? `<tr><td style="padding:6px 0; color:#6b6055;">Email</td><td style="padding:6px 0;">${email}</td></tr>` : ""}
      ${phone ? `<tr><td style="padding:6px 0; color:#6b6055;">Phone</td><td style="padding:6px 0;">${phone}</td></tr>` : ""}
      <tr><td style="padding:6px 0; color:#6b6055;">Requested date</td><td style="padding:6px 0;">${fmtDate(preferredDate)}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Requested time</td><td style="padding:6px 0;">${preferredTime}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Location</td><td style="padding:6px 0;">${location}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Agent</td><td style="padding:6px 0;">${agentName || "— not provided —"}</td></tr>
    </table>
    <p>Review this booking in the admin dashboard.</p>
    `
  );
}

export function bookingApprovedTemplate(params: {
  name: string;
  ref: string;
  preferredDate: Date | string;
  preferredTime: string;
  location: string;
}): string {
  const { name, ref, preferredDate, preferredTime, location } = params;
  return layout(
    "Your inspection is confirmed",
    `
    <p>Hi ${name},</p>
    <p>Your inspection booking <strong>${ref}</strong> has been confirmed as requested:</p>
    <table style="width:100%; border-collapse: collapse; margin: 16px 0;">
      <tr><td style="padding:6px 0; color:#6b6055;">Date</td><td style="padding:6px 0; font-weight:bold;">${fmtDate(preferredDate)}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Time</td><td style="padding:6px 0; font-weight:bold;">${preferredTime}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Location</td><td style="padding:6px 0;">${location}</td></tr>
    </table>
    <p>We look forward to seeing you then.</p>
    `
  );
}

export function bookingRescheduledTemplate(params: {
  name: string;
  ref: string;
  rescheduledDate: Date | string;
  rescheduledTime: string;
  location: string;
}): string {
  const { name, ref, rescheduledDate, rescheduledTime, location } = params;
  return layout(
    "Your inspection has been rescheduled",
    `
    <p>Hi ${name},</p>
    <p>Your inspection booking <strong>${ref}</strong> has a new date and time:</p>
    <table style="width:100%; border-collapse: collapse; margin: 16px 0;">
      <tr><td style="padding:6px 0; color:#6b6055;">New date</td><td style="padding:6px 0; font-weight:bold;">${fmtDate(rescheduledDate)}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">New time</td><td style="padding:6px 0; font-weight:bold;">${rescheduledTime}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Location</td><td style="padding:6px 0;">${location}</td></tr>
    </table>
    <p>If this doesn't work for you, reply to this email and we'll help find another time.</p>
    `
  );
}

const statusCopy: Record<string, { title: string; body: string }> = {
  on_hold: {
    title: "Your inspection booking is on hold",
    body: "Your booking has been placed on hold while we confirm a few details. We'll follow up shortly.",
  },
  under_review: {
    title: "Your inspection booking is under review",
    body: "Your booking is being reviewed by our team. We'll be in touch soon to confirm next steps.",
  },
};

export function bookingStatusTemplate(params: {
  name: string;
  ref: string;
  status: "on_hold" | "under_review";
}): string {
  const { name, ref, status } = params;
  const copy = statusCopy[status];
  return layout(
    copy.title,
    `
    <p>Hi ${name},</p>
    <p>${copy.body}</p>
    <p>Reference: <strong>${ref}</strong></p>
    `
  );
}

export function saleConfirmationTemplate(params: {
  name: string;
  ref: string;
  location: string;
}): string {
  const { name, ref, location } = params;
  return layout(
    "Congratulations on your new property!",
    `
    <p>Hi ${name},</p>
    <p>We're delighted to confirm the sale associated with your inspection at <strong>${location}</strong> (ref <strong>${ref}</strong>) is complete.</p>
    <p>Thank you for choosing Belgrove Homes — our team will be in touch with next steps.</p>
    `
  );
}

export function agentAssignmentTemplate(params: {
  agentName: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string | null;
  ref: string;
  preferredDate: Date | string;
  preferredTime: string;
  rescheduledDate?: Date | string | null;
  rescheduledTime?: string | null;
  location: string;
  agentCategory?: string | null;
}): string {
  const {
    agentName,
    clientName,
    clientEmail,
    clientPhone,
    ref,
    preferredDate,
    preferredTime,
    rescheduledDate,
    rescheduledTime,
    location,
    agentCategory,
  } = params;
  const dateToShow = rescheduledDate ?? preferredDate;
  const timeToShow = rescheduledTime ?? preferredTime;
  const isRescheduled = !!rescheduledDate;
  return layout(
    `New client assigned — ${ref}`,
    `
    <p>Hi ${agentName},</p>
    <p>You have been assigned a new inspection booking to follow up. Please contact the client promptly:</p>
    <table style="width:100%; border-collapse: collapse; margin: 16px 0;">
      <tr><td style="padding:6px 0; color:#6b6055;">Reference</td><td style="padding:6px 0; font-weight:bold;">${ref}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Client</td><td style="padding:6px 0;">${clientName}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Email</td><td style="padding:6px 0;"><a href="mailto:${clientEmail}">${clientEmail}</a></td></tr>
      ${clientPhone ? `<tr><td style="padding:6px 0; color:#6b6055;">Phone</td><td style="padding:6px 0;"><a href="tel:${clientPhone}">${clientPhone}</a></td></tr>` : ""}
      <tr><td style="padding:6px 0; color:#6b6055;">${isRescheduled ? "Rescheduled date" : "Requested date"}</td><td style="padding:6px 0; font-weight:bold;">${fmtDate(dateToShow)}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Time</td><td style="padding:6px 0; font-weight:bold;">${timeToShow}</td></tr>
      <tr><td style="padding:6px 0; color:#6b6055;">Location</td><td style="padding:6px 0;">${location}</td></tr>
      ${agentCategory ? `<tr><td style="padding:6px 0; color:#6b6055;">Your category</td><td style="padding:6px 0; text-transform: capitalize;">${agentCategory.replace("_", " ")}</td></tr>` : ""}
    </table>
    <p style="background:#fef3c7; border:1px solid #fcd34d; padding:12px; border-radius:4px; font-size:13px;">Action required: Contact <strong>${clientName}</strong> within 24 hours to confirm the inspection and provide directions. Reply to this email if you need admin support.</p>
    <p>Client reference: <strong>${ref}</strong></p>
    `
  );
}
