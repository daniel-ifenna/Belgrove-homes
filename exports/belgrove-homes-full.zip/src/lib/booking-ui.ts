export const statusLabels: Record<string, string> = {
  new: "New",
  under_review: "Under Review",
  on_hold: "On Hold",
  approved: "Approved",
  rescheduled: "Rescheduled",
  active: "Active",
  closed: "Closed",
};

export const statusColors: Record<string, string> = {
  new: "bg-blue-100 text-blue-800",
  under_review: "bg-amber-100 text-amber-800",
  on_hold: "bg-orange-100 text-orange-800",
  approved: "bg-emerald-100 text-emerald-800",
  rescheduled: "bg-purple-100 text-purple-800",
  active: "bg-teal-100 text-teal-800",
  closed: "bg-stone-200 text-stone-700",
};

export const temperatureColors: Record<string, string> = {
  cold: "bg-sky-100 text-sky-800",
  warm: "bg-amber-100 text-amber-800",
  hot: "bg-red-100 text-red-800",
};

export const allStatuses = [
  "new",
  "under_review",
  "on_hold",
  "approved",
  "rescheduled",
  "active",
  "closed",
] as const;

export const allTemperatures = ["cold", "warm", "hot"] as const;

export function formatDate(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
}

export function formatDateTime(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}
