import type { BookingStatus, LeadTemperature } from "@/generated/prisma/client";

export type BookingAction =
  | "approve"
  | "reschedule"
  | "hold"
  | "under_review"
  | "mark_active"
  | "record_outcome"
  | "save"
  | "escalate_lead"
  | "assign_agent";

// "save", "escalate_lead", "assign_agent" are status-independent — they never
// change status, so they're excluded from the transition map and always allowed.
type StatusGatedAction = Exclude<BookingAction, "save" | "escalate_lead" | "assign_agent">;

/**
 * Which statuses each action is legal from.
 *
 * Mirrors the workflow described in the spec:
 *   Review (new/on_hold/under_review) -> Approve/Reschedule -> Active -> Sold/Not Sold
 * Approve/reschedule/hold/under_review remain available to each other after
 * the first pass so an admin can correct course before the session happens.
 */
export const ALLOWED_FROM: Record<StatusGatedAction, BookingStatus[]> = {
  approve: ["new", "under_review", "on_hold", "approved", "rescheduled"],
  reschedule: ["new", "under_review", "on_hold", "approved", "rescheduled"],
  hold: ["new", "under_review", "approved", "rescheduled"],
  under_review: ["new", "on_hold", "approved", "rescheduled"],
  mark_active: ["approved", "rescheduled"],
  record_outcome: ["active"],
};

export function isTransitionAllowed(action: BookingAction, status: BookingStatus): boolean {
  if (action === "save" || action === "escalate_lead" || action === "assign_agent") return true;
  return ALLOWED_FROM[action].includes(status);
}

export const actionLabels: Record<BookingAction, string> = {
  approve: "Approve",
  reschedule: "Reschedule",
  hold: "Put on hold",
  under_review: "Mark under review",
  mark_active: "Mark as active",
  record_outcome: "Record outcome",
  save: "Edit fields",
  escalate_lead: "Escalate lead",
  assign_agent: "Assign agent",
};

// cold -> warm -> hot. Used to enforce "escalate only" — a manual change
// must strictly raise the rank; it can never lower it. The one place
// leadTemperature legitimately goes down is the automatic not_sold rule
// in the record_outcome action, which bypasses this check entirely.
export const temperatureRank: Record<LeadTemperature, number> = {
  cold: 0,
  warm: 1,
  hot: 2,
};

export function isEscalation(from: LeadTemperature, to: LeadTemperature): boolean {
  return temperatureRank[to] > temperatureRank[from];
}
