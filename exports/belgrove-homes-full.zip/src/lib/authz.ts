// Admins and staff share full dashboard access per spec §10 — both are
// authenticated internal users, there's no reduced "staff" tier.
export function isInternalRole(role: string | null | undefined): boolean {
  return role === "admin" || role === "staff";
}
