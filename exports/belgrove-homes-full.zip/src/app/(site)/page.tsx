"use client";
import Link from "next/link";
import { useState, useEffect } from "react";
import CinematicIntroLoader from "@/components/site/CinematicIntroLoader";

function TypewriterWelcome() {
  const full = "Welcome to Belgrove";
  const [text, setText] = useState("");
  const [done, setDone] = useState(false);
  useEffect(() => {
    let i = 0;
    const t = setInterval(() => { i++; setText(full.slice(0, i)); if (i >= full.length) { clearInterval(t); setDone(true); } }, 72);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="flex flex-col items-center text-center px-6">
      <div className="mono text-[11px] tracking-[0.24em] uppercase text-[#C79A46] mb-5 opacity-0" style={{ animation: "fadeIn 0.7s ease 0.2s forwards" }}>Belgrove Homes & Properties Limited — Est. 2008</div>
      <h1 className="fraunces font-[500] text-[#F7F2E7] leading-none" style={{ fontSize: "clamp(2.8rem, 7vw, 4.8rem)", letterSpacing: "-0.02em", textShadow: "0 4px 28px rgba(0,0,0,0.45)" }}>
        <span className="inline-flex items-center">{text}<span className={`inline-block w-[3px] h-[1.05em] bg-[#E4C892] ml-1.5 ${done ? "opacity-0" : "animate-pulse"}`} style={{ transition: "opacity 0.4s" }} /></span>
      </h1>
      <div className="fraunces italic text-[#E4C892] mt-4 opacity-0" style={{ fontSize: "clamp(1.05rem, 2.5vw, 1.4rem)", animation: `fadeIn 0.9s ease ${done ? "0.4s" : "2.2s"} forwards` }}>Land. Value. Legacy.</div>
      <div className="mono text-[10px] tracking-[0.16em] uppercase text-[#B9C7BB] mt-3 opacity-0" style={{ animation: `fadeIn 0.9s ease ${done ? "0.7s" : "2.5s"} forwards` }}>The ground for your future — Where trust is titled</div>
      <style>{`@keyframes fadeIn{to{opacity:1}}`}</style>
    </div>
  );
}

export default function HomePage() {
  const [wealthStep, setWealthStep] = useState(0);
  const [openVerify, setOpenVerify] = useState(0);
  const [promiseTab, setPromiseTab] = useState(0);
  const [activePlotFilter, setActivePlotFilter] = useState("All");
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [headerSlide, setHeaderSlide] = useState(0);
  useEffect(() => { const t = setInterval(() => setHeaderSlide((s) => (s + 1) % 2), 6500); return () => clearInterval(t); }, []);
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver((entries) => { entries.forEach((e) => { if (e.isIntersecting) { (e.target as HTMLElement).classList.add("in-view"); io.unobserve(e.target); } }); }, { threshold: 0.14 });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <div className="bg-[#F7F2E7] text-[#211D17]">
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      {/* eslint-disable-next-line @next/next/no-page-custom-font */}
      <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;1,9..144,500&family=Public+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet" />
      {/* eslint-disable-next-line @next/next/no-css-tags */}
      <link rel="stylesheet" href="/cinematic-intro.css" />
      <CinematicIntroLoader />
      <div id="cinematic" style={{ background: "#0F1A12" }}>
        <div className="cin-stage" style={{ background: "radial-gradient(ellipse 900px 560px at 50% 40%, rgba(199,154,70,0.14), transparent 62%), linear-gradient(180deg, #152219 0%, #0F1A12 100%)" }}>
          <TypewriterWelcome />
          <div className="cin-progress" style={{ background: "rgba(247,242,231,0.12)" }}><div className="cin-progress-bar" style={{ background: "linear-gradient(90deg, #C79A46, #E4C892)" }} /></div>
          <div className="cin-skip" style={{ color: "rgba(228,200,146,0.6)" }}>Click anywhere to enter</div>
        </div>
      </div>
      <style>{`.fraunces{font-family:Fraunces,serif} .mono{font-family:IBM Plex Mono,monospace} .public{font-family:Public Sans,sans-serif} .reveal{opacity:0; transform:translateY(14px); transition:opacity .6s ease, transform .6s ease} .reveal.in-view{opacity:1; transform:translateY(0)} .card-hover{transition:transform .25s ease, box-shadow .25s ease} .card-hover:hover{transform:translateY(-3px); box-shadow:0 12px 28px rgba(31,51,40,0.12)}`}</style>

      {/* HERO — F + screen-fit slider */}
      <section className="relative h-screen w-full overflow-hidden bg-black">
        <div className={`absolute inset-0 transition-opacity duration-700 ${headerSlide === 0 ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
          <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover"><source src="/belgrove-legacy-night-aerial.mp4" type="video/mp4" /></video>
          <div className="absolute inset-0 bg-black/32" />
          <div className="absolute left-4 lg:left-12 bottom-[18%] max-w-[640px] pr-4">
            <div className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46] bg-white/92 backdrop-blur px-2.5 py-1 rounded-[2px] inline-block">Building Dreams, Delivering Excellence</div>
            <h1 className="fraunces font-[500] text-white leading-[1.02] mt-3" style={{ fontSize: "clamp(30px, 4.4vw, 44px)", textShadow: "0 2px 18px rgba(0,0,0,0.45)" }}>Consider this your invitation to the ground beneath your future.</h1>
            <p className="public text-white/90 text-[13px] leading-[1.5] mt-3 max-w-[48ch]">Verified land. Premium service. And guidance that keeps your tomorrow in mind from the very first hello.</p>
            <p className="mono text-[10px] tracking-[0.12em] uppercase text-white/70 mt-2">Building Africa’s Future, One Exceptional Space at a Time</p>
          </div>
        </div>
        <div className={`absolute inset-0 transition-opacity duration-700 ${headerSlide === 1 ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
          <img src="/belgrove-team.jpg" alt="Belgrove team" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#1F3328]/38" />
          <div className="absolute left-4 lg:left-12 bottom-[18%] max-w-[620px] pr-4">
            <div className="mono text-[11px] tracking-[0.16em] uppercase text-[#1F3328] bg-[#C79A46] px-2.5 py-1 rounded-[2px] inline-block font-medium">No Rent Campaign — Own, Don’t Rent</div>
            <h2 className="fraunces font-[500] text-white leading-[1.02] mt-3" style={{ fontSize: "clamp(30px, 4.4vw, 44px)", textShadow: "0 2px 18px rgba(0,0,0,0.45)" }}>Stop Renting. Start Owning Ground.</h2>
            <p className="public text-white/90 text-[13px] leading-[1.55] mt-3 max-w-[52ch]" style={{ textShadow: "0 1px 8px rgba(0,0,0,0.4)" }}>
              Why pay rent forever when you can own titled land that grows? The No Rent Campaign moves first-time buyers from monthly rent receipts to title deeds — verified, transparent, and structured to fit real incomes. From rent to legacy, in one decision.
            </p>
            <Link href="/book-inspection" className="mono inline-flex mt-4 text-[11px] tracking-[0.12em] uppercase bg-[#C79A46] text-[#1F3328] px-4 py-2 rounded-[2px] hover:bg-[#E4C892] transition-colors font-medium">Join No Rent Campaign →</Link>
          </div>
        </div>
        <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-1.5">
          {[0,1].map(i=>(
            <button key={i} onClick={()=>setHeaderSlide(i)} className={`h-1.5 rounded-full transition-all ${headerSlide===i ? "w-6 bg-[#C79A46]" : "w-1.5 bg-white/45"}`} />
          ))}
        </div>
      </section>

      {/* Welcome — expanded, asymmetrical */}
      <section id="welcome" className="bg-[#F7F2E7] py-14 border-b border-[#E0D5BB] overflow-hidden reveal">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-8 lg:gap-12 items-center">
            <div className="relative order-2 lg:order-1">
              <div className="relative rounded-[4px] overflow-hidden border border-[#E0D5BB] aspect-[1.2/0.9] bg-white shadow-[0_16px_32px_rgba(31,51,40,0.08)]">
                <img src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=900&auto=format&fit=crop" alt="Open land" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute bottom-3 left-3 mono text-[10px] tracking-[0.14em] uppercase bg-[#1F3328] text-[#E4C892] px-2 py-1 rounded-[2px]">Honest investment · Since 2008</div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Welcome — Headquarters, Lagos</span>
              <h2 className="fraunces text-[27px] leading-[1.12] text-[#1F3328] mt-3">The most honest investment <span className="italic text-[#8B5E3C]">there is.</span></h2>
              <div className="public text-[14px] leading-[1.7] text-[#211D17] mt-4 space-y-4">
                <p>At <strong className="font-semibold text-[#1F3328]">Belgrove Homes &amp; Properties Limited</strong>, we believe a piece of land is the most honest investment there is. It does not move, decline, or wear out; it waits for you — patient, quiet, and certain. While markets swing and currencies waver, ground remains. That certainty is why discerning families and disciplined investors alike return to land, again and again.</p>
                <p>Build the home you have imagined — a courtyard for laughter, a study for late nights, a garden that will outgrow your children. Hold an asset that grows with the years, hedged against inflation and time, appreciating as roads open and neighborhoods mature. Or lay the foundation of a future your family can stand on — a plot that becomes a home, then a compound, then a legacy whispered at family tables decades from now.</p>
                <p>Whatever your dream — first home, portfolio expansion, or a quiet hedge for the next generation — it begins with the right ground beneath it. We exist to make that first decision the most confident one you will ever make: verified, titled, and guided by people who will still answer your call after the deed is signed.</p>
              </div>
              <div className="flex gap-2 mt-6 mono text-[11px]">
                <span className="px-3 py-1.5 rounded-full bg-[#1F3328] text-[#E4C892]">Verified & Titled</span>
                <span className="px-3 py-1.5 rounded-full bg-white border border-[#E0D5BB]">Named adviser</span>
                <span className="px-3 py-1.5 rounded-full bg-white border border-[#E0D5BB]">No pressure</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Land — expanded */}
      <section className="bg-[#1F3328] py-14 relative overflow-hidden reveal">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23E4C892' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4z'/%3E%3C/g%3E%3C/svg%3E")` }} />
        <div className="relative max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-[1.22fr_0.78fr] gap-8 lg:gap-10 items-start">
            <div>
              <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#B9C7BB]">Why Land, Why Now — A Head of Marketing Perspective</span>
              <blockquote className="fraunces italic leading-[1.32] text-[#E4C892] mt-4" style={{ fontSize: "clamp(21px, 2.5vw, 27px)" }}>
                “Real estate cannot be lost or stolen, nor can it be carried away. Purchased with common sense, paid for in full, and managed with reasonable care, it is about the safest investment in the world.”
              </blockquote>
              <div className="mono text-[11px] tracking-[0.14em] uppercase text-[#B9C7BB] mt-3">— Franklin D. Roosevelt, as relevant in Lagos today as in New York then</div>
              <div className="public text-[#D9E0D5] leading-[1.65] mt-6 space-y-4" style={{ fontSize: "14.5px" }}>
                <p>Land has quietly become the smartest conversation in property — not because buildings have lost value, but because land alone asks for constant care and returns potential over time but <em className="text-[#E4C892] not-italic">only when chosen well</em>. In a city where new roads redraw maps overnight and corridors like Epe, Ibeju-Lekki and Mowe double in relevance within a decade, the difference between a good plot and a costly one is not price — it is due diligence.</p>
                <p>That is our work as your brand custodians: to find plots with genuine long-term promise — titled, accessible, free of encumbrance, with a clear path to infrastructure — verify them against our 7-point Belgrove Land Verification Standard, and hand them to you with complete clarity. No embellishment. No hidden caveats. Because a plot chosen today should still feel right when your child stands on it decades from now, and because trust, once broken, is land’s most expensive encumbrance.</p>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-8 mono text-center">
                <div className="bg-white/5 border border-white/10 rounded-[4px] p-3"><div className="fraunces text-[#E4C892] text-[16px]">Hedge</div><div className="text-[11px] text-[#B9C7BB]">Against inflation</div></div>
                <div className="bg-white/5 border border-white/10 rounded-[4px] p-3"><div className="fraunces text-[#E4C892] text-[16px]">Patient</div><div className="text-[11px] text-[#B9C7BB]">Grows quietly</div></div>
                <div className="bg-white/5 border border-white/10 rounded-[4px] p-3"><div className="fraunces text-[#E4C892] text-[16px]">Legacy</div><div className="text-[11px] text-[#B9C7BB]">Outlives buildings</div></div>
              </div>
            </div>
            <div className="relative">
              <div className="relative rounded-[4px] overflow-hidden border border-white/10 aspect-[1.05/0.95] bg-[#152219] shadow-[0_20px_40px_rgba(0,0,0,0.28)]">
                <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=800&auto=format&fit=crop" alt="Mature landscape" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute bottom-0 inset-x-0 bg-[#1F3328]/90 backdrop-blur px-4 py-3">
                  <div className="mono text-[10px] tracking-[0.14em] uppercase text-[#E4C892]">Marketing lens</div>
                  <div className="public text-[12px] text-white mt-1">Land chosen well today still rewards decades from now — that is the story we protect.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Wealth steps — expanded */}
      <section className="bg-[#F7F2E7] py-14 border-y border-[#E0D5BB] overflow-hidden reveal">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-[0.85fr_1.15fr] gap-8 lg:gap-10 items-center">
            <div className="relative order-2 lg:order-1">
              <div className="relative rounded-[4px] overflow-hidden border border-[#E0D5BB] aspect-[1.05/0.95] bg-white shadow-[0_16px_32px_rgba(31,51,40,0.08)]">
                <img src="https://images.unsplash.com/photo-1600607687644-c7171b42498b?q=80&w=800&auto=format&fit=crop" alt="Family home" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute top-3 left-3 mono text-[10px] tracking-[0.12em] uppercase bg-[#1F3328] text-[#E4C892] px-2 py-1 rounded-[2px]">Brand promise: Build · Hold · Grow</div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Wealth steps — The Belgrove Method</span>
              <h2 className="fraunces text-[30px] leading-[1.05] text-[#1F3328] mt-2">Build. Hold. Grow.</h2>
              <p className="public text-[13px] leading-[1.6] text-[#8B5E3C] mt-2">Three words that shape every advisory conversation. Whether you are pouring a foundation next quarter or holding for a decade, the discipline is the same.</p>
              <div className="flex gap-2 mt-5 flex-wrap">
                {["Build","Hold","Grow"].map((label,i)=>(
                  <button key={label} onClick={()=>setWealthStep(i)} className={`fraunces italic px-5 py-2 rounded-full border text-[13px] transition-all ${wealthStep===i ? "bg-[#1F3328] text-[#E4C892] border-[#1F3328]" : "bg-white text-[#8B5E3C] border-[#E0D5BB] hover:border-[#C79A46]"}`}>{label}</button>
                ))}
              </div>
              <div className="mt-5 min-h-[140px]">
                {wealthStep===0 && <div className="bg-white border border-[#E0D5BB] rounded-[4px] p-5"><h3 className="fraunces text-[16px] text-[#1F3328]">Build: The plot for the home you have imagined.</h3><p className="public text-[13.5px] leading-[1.6] text-[#8B5E3C] mt-2">We start with your vision — not our inventory. How many bedrooms? How close to work? What does “home” feel like at 7am? From that warm first conversation we curate plots where that life fits, verify each, handle transfer and registration, and stay through foundation. You don’t just buy ground; you buy a clear path to front door.</p><p className="mono text-[11px] text-[#1F3328] mt-3">→ Ideal for families ready to build within 0–24 months.</p></div>}
                {wealthStep===1 && <div className="bg-white border border-[#E0D5BB] rounded-[4px] p-5"><h3 className="fraunces text-[16px] text-[#1F3328]">Hold: An asset that waits for you.</h3><p className="public text-[13.5px] leading-[1.6] text-[#8B5E3C] mt-2">Not every plot must be built tomorrow. Held land, well chosen, is patient capital — hedged against inflation, free of tenant headaches, quietly appreciating as roads, schools and commerce arrive. We help you select corridors with real long-term potential (Epe’s industrial spine, Ibeju’s coastal momentum) and we tell you honestly when to wait. Land rewards patience — we reward it with discipline.</p><p className="mono text-[11px] text-[#1F3328] mt-3">→ Ideal for investors building a 3–10 year portfolio.</p></div>}
                {wealthStep===2 && <div className="bg-white border border-[#E0D5BB] rounded-[4px] p-5"><h3 className="fraunces text-[16px] text-[#1F3328]">Grow: A legacy for your family.</h3><p className="public text-[13.5px] leading-[1.6] text-[#8B5E3C] mt-2">Property, well planned, is one of the surest foundations of enduring wealth — because it compounds beyond you. A plot bought wisely today becomes a home for your children, a rental that funds education, or a parcel that multiplies when the neighborhood matures. As head of marketing, I call this “the quiet ROI”: value that grows while you sleep, and a story your family will tell long after the transfer papers fade.</p><p className="mono text-[11px] text-[#1F3328] mt-3">→ Ideal for generational wealth — 10+ year horizon.</p></div>}
              </div>
              <p className="fraunces italic text-[14px] text-[#8B5E3C] mt-4">Your future starts with a quiet invitation and the right ground. Which step are you on?</p>
            </div>
          </div>
        </div>
      </section>

      {/* How We Build — detailed */}
      <section className="bg-white border-y border-[#E0D5BB] py-16 reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">How we build — end to end, Fortune 500 discipline</span>
          <h2 className="fraunces text-[30px] leading-[1.05] text-[#1F3328] mt-2">One team owns the <span className="italic text-[#8B5E3C]">entire lifecycle</span></h2>
          <p className="public text-[14px] leading-[1.6] text-[#8B5E3C] max-w-[68ch] mt-3">We acquire, title, service, build community infrastructure, and remain as estate managers — so no estate stalls at “coming soon.” This end-to-end ownership is our brand moat: escrow-tracked funds, ISO-grade verification, weekly public build diaries you can attend, and a named adviser who knows your plot by heart. Marketing can promise; delivery must prove.</p>
          <div className="relative rounded-[4px] overflow-hidden bg-[#152219] mt-8 shadow-[0_16px_40px_rgba(15,26,18,0.14)]">
            <div className="relative aspect-[16/7.5] overflow-hidden">
              <img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=1600&auto=format&fit=crop" alt="Completed estate" className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(21,34,25,0.08), rgba(21,34,25,0.58))" }} />
              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between gap-4">
                <div className="bg-white/95 backdrop-blur rounded-[4px] px-4 py-3"><div className="mono text-[10px] tracking-[0.14em] uppercase text-[#8B5E3C]">Live estate — Belgrove IV</div><div className="fraunces text-[15px] text-[#1F3328] mt-1">Roads, power, school and clinic before handover — see before you buy.</div></div>
                <Link href="/book-inspection" className="hidden sm:inline-flex public text-[13px] font-semibold bg-[#C79A46] text-[#152219] px-5 py-2.5 rounded-[2px]">Tour this estate →</Link>
              </div>
            </div>
            <div className="flex gap-1.5 px-2 pt-2 bg-[#F7F2E7] mono text-[10px]">
              {["All","Empty","Construction","Rising","Home"].map(f=>(
                <button key={f} onClick={()=>setActivePlotFilter(f)} className={`px-2.5 py-1 rounded-full border ${activePlotFilter===f?"bg-[#1F3328] text-white border-[#1F3328]":"bg-white text-[#8B5E3C] border-[#E0D5BB] hover:border-[#1F3328]"}`}>{f}</button>
              ))}
              <span className="ml-auto mono text-[10px] tracking-[0.12em] uppercase text-[#8B5E3C] self-center">Interactive filter · Click to enlarge</span>
            </div>
            <div className="grid grid-cols-4 gap-2 p-2 bg-[#F7F2E7]">
              {[
                ["01 · Empty Land","https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=600&auto=format&fit=crop"],
                ["02 · Construction","https://images.unsplash.com/photo-1541888946425-d81bb19240f6?q=80&w=600&auto=format&fit=crop"],
                ["03 · Rising","https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=600&auto=format&fit=crop"],
                ["04 · Dream Home","https://images.unsplash.com/photo-1600573472592-401b489a3cdc?q=80&w=600&auto=format&fit=crop"],
              ].filter(([label])=> activePlotFilter==="All" || label.toLowerCase().includes(activePlotFilter.toLowerCase())).map(([label,img])=>(
                <figure key={label} onClick={()=>setLightbox(img)} className="relative rounded-[4px] overflow-hidden aspect-[1.35] bg-white card-hover cursor-pointer group">
                  <img src={img} alt={label} className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-500" />
                  <figcaption className="absolute bottom-0 inset-x-0 mono text-[9px] tracking-[0.12em] uppercase text-center px-1 py-1.5 bg-[#1F3328]/88 text-white">{label}</figcaption>
                  <span className="absolute top-1.5 right-1.5 h-5 w-5 rounded-full bg-white/90 grid place-items-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity">⤢</span>
                </figure>
              ))}
            </div>
            {lightbox && (
              <div className="fixed inset-0 z-50 bg-[#0F1A12]/85 backdrop-blur flex items-center justify-center p-6" onClick={()=>setLightbox(null)}>
                <img src={lightbox} alt="" className="max-w-[90vw] max-h-[86vh] rounded-[4px] shadow-[0_20px_60px_rgba(0,0,0,0.4)]" />
                <button className="absolute top-6 right-6 h-9 w-9 rounded-full bg-white grid place-items-center text-[#1F3328]" onClick={()=>setLightbox(null)}>✕</button>
              </div>
            )}
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4 mt-8">
            {[
              { n:"01", t:"Acquisition", d:"We don’t list what we haven’t walked. Every acre is surveyed, titled and de-risked — only land with a clear corridor to infrastructure ever reaches you.", s:"2,400+ acres" },
              { n:"02", t:"Master Plan", d:"Roads, drainage, power and zoning are engineered and approved before the first block is laid — so your 450sqm is never an island.", s:"100% approved" },
              { n:"03", t:"Construction", d:"Vetted crews under ISO supervision, weekly diaries open to clients. Visit any Tuesday — hard hat provided, progress proven.", s:"180+ workers" },
              { n:"04", t:"Vertical Build", d:"Serviced plots become terraces, detached homes and mixed-use blocks rising in parallel — choice, not compromise.", s:"6 estates" },
              { n:"05", t:"Infrastructure", d:"Schools, clinic, market and faith plots delivered with phase 1, not phase “later.” Community on day one.", s:"5 amenities" },
              { n:"06", t:"Handover", d:"Deed, keys and estate services. Move-in ready, fully documented, and managed by the team that built it.", s:"1,200 families" },
            ].map(s=>(
              <div key={s.n} className="bg-[#F7F2E7] border border-[#E0D5BB] rounded-[4px] p-4 card-hover">
                <div className="h-6 w-6 rounded-full bg-[#1F3328] text-[#E4C892] grid place-items-center mono text-[11px]">{s.n}</div>
                <div className="fraunces text-[15px] text-[#1F3328] mt-2">{s.t}</div>
                <div className="public text-[12.5px] leading-[1.5] text-[#8B5E3C] mt-1">{s.d}</div>
                <div className="mono text-[10px] tracking-[0.12em] uppercase text-[#C79A46] mt-3 pt-3 border-t border-dashed border-[#E0D5BB]">{s.s}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT — detailed, marketing head voice */}
      <section id="about" className="bg-[#F7F2E7] py-12 lg:py-16 overflow-hidden reveal">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-[1.18fr_0.82fr] gap-8 lg:gap-12 items-start">
            <div className="lg:pr-4">
              <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">About Us — The Belgrove Story, Told by Marketing</span>
              <h2 className="fraunces text-[32px] lg:text-[36px] leading-[0.92] tracking-[-0.015em] text-[#1F3328] mt-3">Who we are, and why land</h2>
              <div className="grid sm:grid-cols-2 gap-6 mt-8">
                <div>
                  <h3 className="public font-semibold text-[13px] tracking-[0.06em] uppercase text-[#1F3328]">Who we are</h3>
                  <p className="public text-[13.5px] leading-[1.65] text-[#211D17] mt-2">Belgrove Homes &amp; Properties Limited was born in 2008 on a single conviction that still hangs framed in our Lagos reception: <em className="italic text-[#8B5E3C]">real estate is far more than the acquisition of ground or buildings; it is a foundation for financial growth, for security, and for a generational legacy.</em> What began as two colleagues above a coffee shop — walking every plot, photographing every boundary, losing sales to honesty — is now a 34-person house of acquisitions, verification, advisory and estate management. We have made land the heart of that belief, because a brand that endures must stand on ground that endures.</p>
                </div>
                <div>
                  <h3 className="public font-semibold text-[13px] tracking-[0.06em] uppercase text-[#1F3328]">Why land — our first love</h3>
                  <p className="public text-[13.5px] leading-[1.65] text-[#211D17] mt-2">We chose land for a simple, almost poetic reason: it is where everything meaningful in property begins. A building ages, styles fade, roofs leak — but a plot endures. It gives you freedom: build when ready, hold while you plan, pass on something that outlives you. In a market where buildings depreciate and trends expire, land — well chosen — is the firmest ground on which to build wealth, the one asset you can stand on, literally and financially.</p>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-6 mt-8">
                <div>
                  <h3 className="public font-semibold text-[13px] tracking-[0.06em] uppercase text-[#1F3328]">Our difference — premium, yet warm</h3>
                  <p className="public text-[13.5px] leading-[1.65] text-[#211D17] mt-2">We are premium in quality and warm in manner — a deliberate duality. No pressure, no jargon, no hidden process. Every client receives a named adviser (not a call centre), verified land, transparent fees, and an honest view — even when honesty means advising you to wait. As head of marketing, I measure success not in closings, but in clients who return with their siblings. That warmth is our moat; quality is our standard.</p>
                </div>
                <div>
                  <h3 className="public font-semibold text-[13px] tracking-[0.06em] uppercase text-[#1F3328]">Who we serve — from heirs to portfolios</h3>
                  <p className="public text-[13.5px] leading-[1.65] text-[#211D17] mt-2">First-time heirs who have never bought land before, and seasoned portfolio builders on their fourth plot. Families planning a first home where children will learn to ride a bicycle, investors assembling a corridor of assets, and communities watching their neighborhoods flourish because we stayed to manage the estate. If you value clarity over hype, you are already one of us.</p>
                </div>
              </div>
            </div>
            <div className="relative lg:translate-y-2">
              <div className="relative rounded-[4px] overflow-hidden border border-[#E0D5BB] aspect-[0.95/1.05] bg-white shadow-[0_20px_40px_rgba(31,51,40,0.12)]">
                <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=900&auto=format&fit=crop" alt="Belgrove team" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute bottom-0 inset-x-0 bg-[#1F3328]/88 backdrop-blur px-4 py-3">
                  <div className="mono text-[10px] tracking-[0.14em] uppercase text-[#E4C892]">18 years · 6 estates · 1,200 families · 34 people, one promise</div>
                  <div className="public text-[12px] text-white mt-1">We walk every plot before you do — and we stay after you build.</div>
                </div>
              </div>
              <div className="hidden lg:block absolute -z-10 -right-4 -bottom-4 w-[86%] h-[88%] bg-white border border-[#E0D5BB] rounded-[4px]" />
            </div>
          </div>
          <div className="mt-10">
            <h3 className="mono text-[11px] tracking-[0.18em] uppercase text-[#8B5E3C]">Our values — the brand code</h3>
            <div className="grid md:grid-cols-5 gap-3 mt-4">
              {[
                ["Integrity","We verify, disclose, and tell the truth even when it costs a sale. In marketing, trust is the only campaign that never ends."],
                ["Clarity","If you do not understand something, we have not finished our job. Jargon is a failure of service, not a sign of expertise."],
                ["Value","We position every opportunity for long-term worth, not short-term gain. A quick flip is not a Belgrove story."],
                ["Warmth","Premium service with a human welcome at every step. You will know your adviser’s name and direct line."],
                ["Legacy","We help you build assets that outlast you. The best brief we ever receive is from your future grandchildren."],
              ].map(([k,v],i)=>(
                <div key={k} className={`bg-white border border-[#E0D5BB] rounded-[4px] p-4 card-hover ${i===2 ? "lg:translate-y-3" : i===4 ? "lg:translate-y-1" : ""}`}>
                  <div className="fraunces text-[14px] text-[#1F3328]">{k}</div>
                  <div className="public text-[12.5px] leading-[1.45] text-[#8B5E3C] mt-1">— {v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* OUR VISION — detailed */}
      <section className="bg-white border-y border-[#E0D5BB] py-12 lg:py-16 overflow-hidden reveal">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-[0.88fr_1.12fr] gap-8 lg:gap-12 items-center">
            <div className="relative lg:translate-x-2">
              <div className="relative rounded-[4px] overflow-hidden border border-[#E0D5BB] aspect-[1.05/0.92] shadow-[0_20px_40px_rgba(21,34,25,0.12)]">
                <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover"><source src="/belgrove-legacy-night-aerial.mp4" type="video/mp4" /></video>
                <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(21,34,25,0.08), rgba(21,34,25,0.52))" }} />
                <span className="absolute bottom-3 left-3 mono text-[10px] tracking-[0.12em] uppercase bg-[#1F3328]/78 text-white px-2.5 py-1 rounded-[2px] border border-white/10">FOR THE LONG TERM — VISION 2035</span>
              </div>
              <div className="hidden lg:block absolute -z-10 -left-4 top-4 bottom-4 w-[86%] bg-[#F7F2E7] border border-[#E0D5BB] rounded-[4px]" />
            </div>
            <div className="lg:pl-4">
              <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Our Vision — Where we are headed</span>
              <h2 className="fraunces text-[26px] lg:text-[28px] leading-[1.12] tracking-[-0.01em] text-[#1F3328] mt-3">To build a globally respected real estate brand known for creating exceptional land and property opportunities, delivering lasting value, and empowering individuals and generations to build enduring wealth through real estate.</h2>
              <div className="public text-[14px] leading-[1.65] text-[#8B5E3C] mt-4 space-y-3">
                <p>This is not ambition for its own sake. In branding, “globally respected” is not a billboard — it is a whisper earned plot by plot. We long for a Belgrove name synonymous with trust, one that people recommend to their children as surely as we help them lay foundations.</p>
                <p>It means earning respect transaction by transaction, until the brand itself becomes a foundation others build upon — the quiet moment when a client says, “My father bought from Belgrove, so will I.” That is the vision: not the biggest developer, but the most trusted.</p>
              </div>
              <div className="mt-6 space-y-1 border-l-2 border-[#C79A46] pl-4">
                <div className="fraunces italic text-[18px] text-[#1F3328]">Land. Value. Legacy.</div>
                <div className="public text-[13px] text-[#8B5E3C]">The foundation for your wealth and your future — and for ours.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* OUR MISSION — detailed */}
      <section className="bg-[#F7F2E7] py-16 border-b border-[#E0D5BB] reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Our Mission — How we get there</span>
          <h2 className="fraunces text-[26px] leading-[1.25] text-[#1F3328] mt-2 max-w-[46ch]">To make strategic land and real estate opportunities accessible through transparent transactions, quality offerings, professional service, and innovative solutions creating lasting value for our clients, our investors, and our communities.</h2>
          <div className="public text-[14.5px] leading-[1.7] text-[#211D17] mt-6 space-y-4 max-w-[72ch]">
            <p><strong className="text-[#1F3328]">Accessibility is the key word.</strong> We believe exceptional land should not be reserved for those who know the system, speak the jargon, or have a cousin at the registry. As head of marketing, my brief to the team is simple: open the door. Verified listings in plain language, clear fees on page one, honest guidance even when it means saying “not this one,” and payment structures that fit real lives — 12–24 month installments, escrow, and a named adviser who answers on the second ring.</p>
            <p><strong className="text-[#1F3328]">Innovation appears in how we verify, present, and transfer land,</strong> so the experience feels as modern and uncomplicated as it is trustworthy: drone surveys, digital verification packs, virtual tours for diaspora clients, and a transfer process so clear you could explain it to your mother. Lasting value is then not a promise but a process — for clients who build, investors who hold, and communities that watch a bush become a neighborhood they are proud of.</p>
          </div>
        </div>
      </section>

      {/* OUR PROMISE — detailed */}
      <section className="bg-white py-16 reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Our Promise — The Belgrove Standard, in practice</span>
          <h2 className="fraunces text-[28px] text-[#1F3328] mt-2">Clarity, confidence, and value</h2>
          <p className="public text-[14.5px] leading-[1.65] text-[#211D17] mt-4 max-w-[70ch]">At Belgrove, every client deserves clarity, confidence, and value. This is not a slogan laminated for the reception wall. It is a working standard — the checklist our marketing team must clear before a listing ever goes live, and the reason our sales team will talk you out of a plot if it is not right for you.</p>
          <h3 className="mono text-[11px] tracking-[0.14em] uppercase text-[#1F3328] mt-8">What it means in practice — five non-negotiables</h3>
          <div className="grid md:grid-cols-2 gap-0 mt-4">
            {[
              ["Accurate information","Before a listing ever appears, we verify ownership, boundaries, use, and access — and we publish only what we can prove. What you read is what you can rely on, in court, at the bank, and at the family table."],
              ["Professional guidance","Warm, expert advice at every stage, from your first WhatsApp enquiry to the transfer and registration of your land. Your adviser knows your plot number without looking it up."],
              ["Transparent processes","Clear fees, clear steps, no hidden surprises. Our fee sheet fits on one page. You always know where you stand and what you pay — and what you don’t."],
              ["Long-term value","Opportunities carefully positioned to grow with the years, not the quarter. We show you why today’s price is tomorrow’s entry point, with comparable sales and corridor trends, not hype."],
              ["A human welcome","A named adviser who knows your goals and stays with you, unhurried, from first hello to final handover — and who will still pick up when you call to sell."],
            ].map(([t,d])=>(
              <div key={t} className="flex gap-3 py-5 border-t border-[#E0D5BB] pr-6">
                <span className="h-5 w-5 rounded-full bg-[#1F3328] text-[#E4C892] grid place-items-center text-[11px] shrink-0 mt-0.5">✓</span>
                <div><div className="public font-semibold text-[14px] text-[#1F3328]">{t}</div><div className="public text-[13px] leading-[1.5] text-[#8B5E3C] mt-1">{d}</div></div>
              </div>
            ))}
          </div>
          <p className="public text-[14px] leading-[1.65] text-[#8B5E3C] mt-8 italic border-l-2 border-[#C79A46] pl-4">From your first enquiry to the keys in your hand, and the ground beneath your feet, we make your journey with Belgrove seamless, informed, and rewarding — because the most valuable thing we hand over is not a deed, but certainty.</p>
        </div>
      </section>

      {/* WHY CHOOSE — detailed */}
      <section className="bg-[#F7F2E7] border-y border-[#E0D5BB] py-16 reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Why Choose Belgrove Land — From the Marketing Desk</span>
          <h2 className="fraunces text-[28px] text-[#1F3328] mt-2">Value Proposition — why our clients choose, and stay</h2>
          <p className="public text-[13.5px] leading-[1.6] text-[#8B5E3C] mt-3 max-w-[68ch]">In a market crowded with promises, we compete on proof. Here is why families and portfolio builders alike choose Belgrove — and why 63% of our 1,200 handovers came from referrals.</p>
          <div className="grid md:grid-cols-2 gap-0 mt-8">
            {[
              ["Verified before you commit","Title, boundaries, access, and use checked against our strict 7-point standard — and shared as a verification pack you can take to your own lawyer."],
              ["Transparent pricing","No hidden fees, no silent costs; everything in writing from the start. Our price is the price — no “survey fee” surprise at transfer."],
              ["A named human adviser","Never a call centre, never pressure. One person, one direct line, from shortlist to after-sales. We even tell you when to wait."],
              ["Future-minded selection","Locations with real long-term potential, explained honestly with corridor data, not brochure poetry. Epe’s spine, Ibeju’s coast — we show our work."],
              ["A full journey","From shortlist and site visit to survey, transfer, registration, and eventually building — plus trusted architects and builders when you are ready."],
              ["A real legacy","Land that can grow into a home, a portfolio, or a family future — the one asset your children will thank you for, not question."],
            ].map(([t,d])=>(
              <div key={t} className="flex gap-3 py-4 border-t border-[#E0D5BB] pr-6">
                <span className="h-5 w-5 rounded-full bg-[#C79A46] text-white grid place-items-center text-[11px] shrink-0">✓</span>
                <div className="public text-[14px] leading-[1.5]"><span className="font-semibold text-[#1F3328]">{t}</span><span className="text-[#8B5E3C]"> — {d}</span></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* VERIFICATION — detailed */}
      <section id="verification" className="bg-[#1F3328] py-16 reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#E4C892]">The Belgrove Land Verification Standard — Our moat</span>
          <h2 className="fraunces text-[28px] text-[#F7F2E7] mt-2">Accuracy is the heart of our promise</h2>
          <p className="public text-[14px] text-[#C9D2C5] mt-2 max-w-[68ch]">Every plot we present is checked against a clear standard before publication. As head of marketing, I will not let a plot go live until it clears all seven. Accuracy is not a department — it is our entire brand.</p>
          <div className="mt-8">
            {[
              { code:"Title & Ownership", title:"Title & Ownership", body:"The chain of ownership is verified, and the seller's right to sell is confirmed — with documented title you can take to your own counsel. No title, no listing." },
              { code:"Freedom from Encumbrance", title:"Freedom from Encumbrance & Disputes", body:"Checks for claims, liens, caveats, or competing interests — including family and community claims that never appear online." },
              { code:"Boundaries & Size", title:"Boundaries & Size", body:"Plot dimension and boundaries are established by survey / certified measurement — pegged, photographed, and shared. What you see is what you buy." },
              { code:"Use & Planning", title:"Use & Planning Status", body:"What the land may be used for (residential / commercial / development) and any permit position — so you don’t buy residential where only commercial can stand." },
              { code:"Access & Utilities", title:"Access & Utilities", body:"Road access, and the availability of water, power, and other essentials — because land without access is not an asset, it is a burden." },
              { code:"Possession", title:"Possession & Encroachment", body:"We check the land is actually available and free of encroachment or occupation — physically visited, not just checked on paper." },
              { code:"Documentation", title:"Complete Documentation", body:"The documents you need (title / deed / transfer / registration) are explained and, where you wish, coordinated end-to-end — so the paperwork feels as solid as the ground." },
            ].map((v,i)=>(
              <div key={v.code} className="border-t border-white/15">
                <button onClick={()=>setOpenVerify(openVerify===i ? -1 : i)} className="w-full flex items-center gap-4 py-4 text-left">
                  <span className="mono text-[11px] text-[#C79A46] w-[160px] shrink-0 hidden sm:block">{v.code}</span>
                  <span className="fraunces text-[15px] text-[#F7F2E7] flex-1">{v.title}</span>
                  <span className={`text-[#C79A46] text-xl leading-none transition-transform ${openVerify===i ? "rotate-45" : ""}`}>+</span>
                </button>
                <div className={`overflow-hidden transition-all ${openVerify===i ? "max-h-32 pb-4" : "max-h-0"}`}>
                  <p className="public text-[13px] text-[#C9D2C5] sm:ml-[176px] max-w-[64ch]">{v.body}</p>
                </div>
              </div>
            ))}
            <div className="border-b border-white/15" />
          </div>
        </div>
      </section>

      {/* PROMISE TABS & LAND FAQs — keep */}
      <section className="bg-white py-8 border-b border-[#E0D5BB] reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <div className="flex gap-2 flex-wrap">
            {["Our Promise","Why Choose Belgrove"].map((label,i)=>(
              <button key={label} onClick={()=>setPromiseTab(i)} className={`public px-5 py-2.5 rounded-[2px] border text-[14px] font-semibold ${promiseTab===i ? "bg-[#1F3328] text-white border-[#1F3328]" : "bg-white text-[#8B5E3C] border-[#E0D5BB]"}`}>{label}</button>
            ))}
          </div>
          <div className="public text-[13px] leading-[1.6] text-[#8B5E3C] mt-4">
            {promiseTab===0 ? "From accurate information to a human welcome — the standard is lived, not printed. That is the Belgrove difference you feel from first hello." : "Verified, transparent, human — land as legacy, not gamble. That is why referral is our largest channel."}
          </div>
        </div>
      </section>

      <section id="faq" className="bg-[#F7F2E7] py-16 reveal">
        <div className="max-w-[1180px] mx-auto px-6 lg:px-8">
          <div className="text-center max-w-[760px] mx-auto">
            <span className="mono text-[11px] tracking-[0.18em] uppercase text-[#C79A46]">Land FAQs — Answered as your adviser would</span>
            <h2 className="fraunces text-[28px] text-[#1F3328] mt-2">The ground for your future.</h2>
            <p className="public text-[14px] text-[#8B5E3C] mt-2">Buy the land. Build tomorrow. Welcome to the foundation of everything — with answers, not assurances.</p>
          </div>
          <div className="max-w-[860px] mx-auto mt-10">
            {[
              ["Is the land you sell actually yours to sell?","This is the most important question, and we treat it that way. Before publication we verify the chain of ownership and confirm the seller's legal right to sell. Every plot we present is backed by documented title and a clear ownership position and we will walk you through that documentation — page by page — so you understand it before you commit. Bring your lawyer; we welcome it."],
              ["What does “verified land” mean at Belgrove?","It means the plot has passed our 7-point land verification standard: title and ownership confirmed, freedom from encumbrance and disputes checked, boundaries and size established, use/planning status and access confirmed, and complete documentation available. You can request the verification pack for any plot you are serious about — we send it before you pay a naira."],
              ["Can I trust the size and boundaries shown?","We present size based on the surveyor's measurement / certified record, and boundaries are established by pegs and photographs, rather than guessed. We take care you are buying precisely the land you believe you are buying, and we are honest about any measurement caveats — because a square metre hidden is trust lost."],
              ["I want to buy land to build my own home, how does that work?","We start with your vision and budget, then find land suitable for building — the right location, size, use status, and access. We verify the land, coordinate the legal transfer and registration, and connect you with trusted partners for planning and construction. Your goal is to get from plot to foundation with clarity, not complication — and we project-manage that clarity."],
              ["Is land a good long-term investment can I expect it to grow in value?","Land often grows in value over time as areas develop and demand rises, but this is not guaranteed, and no responsible adviser will promise future returns. We seek plots in locations with genuine long-term potential, explain the reasoning with corridor data and comparables, and set realistic expectations. Land is patient by nature, and so is our advice — that patience is our brand promise."],
              ["What is “land banking,” and do you advise on it?","Land banking is buying land to hold for long-term appreciation before building or resale. We can help identify land with future potential and sequence it within a broader portfolio — but we are transparent that returns are not guaranteed and that a plot's prospects should be weighed carefully, with exit options discussed, rather than assumed."],
              ["What documents will I receive after buying land?","You will receive the documentation appropriate to a valid sale, typically the title/deed and the completed legal transfer and registration. We make sure you understand every paper you receive — what it means, where to keep it, and how your family will use it — and, where you wish, we coordinate the transfer on your behalf, end-to-end."],
              ["What if the land has a dispute, an issue, or encroachment?","Our verification is designed to surface these before they become your problem. Where an issue exists, we either resolve it properly — with the right parties and paperwork — or do not present the plot. Our honest standard means we would rather lose a sale than pass a problem to you. That is not just ethics; it is marketing — a problem sold is a reputation lost."],
              ["Can you help me sell my land?","Yes. We value it honestly (even if honest is lower than you hoped), prepare clear documentation, and market it to the right buyers — those building homes and those building portfolios — with the same verification we demand as buyers. Selling land should be as transparent as buying it; your buyer will receive the same pack you did."],
              ["Do you offer payment plans or financing for land","Whether or not you offer them, the full price and any payment structure are disclosed clearly and in writing from the start, with no hidden costs. We offer 12–24 month structures on selected estates; for specifics, your named adviser will lay the schedule beside the total — so you see the ground and the terms, clearly."],
              ["How does your company handle site inspections?","We arrange site visits every week, and for out-of-town or overseas clients we offer virtual tours, drone footage and detailed reports so you can buy with confidence even at a distance. Every visit is hosted — not just a gate opened, but a walk with your adviser who knows the plot number by heart."],
              ["How long does buying land through Belgrove take?","It varies with documentation and transfer requirements, but typically days to weeks for a straightforward plot. We set clear milestones at the start — verification, offer, transfer, registration — and keep you informed at every stage, so waiting feels like progress, not silence."],
            ].map(([q,a])=>(
              <details key={q} className="border-t border-[#E0D5BB] py-4 group bg-white px-4 card-hover">
                <summary className="fraunces text-[15px] text-[#1F3328] flex justify-between items-center cursor-pointer list-none gap-4">{q}<span className="text-[#C79A46] text-xl group-open:hidden shrink-0">+</span><span className="text-[#C79A46] text-xl hidden group-open:block shrink-0">–</span></summary>
                <p className="public text-[13px] leading-[1.6] text-[#8B5E3C] mt-3 max-w-[75ch]">{a}</p>
              </details>
            ))}
            <div className="border-b border-[#E0D5BB]" />
          </div>
        </div>
      </section>

      {/* CTA BAND — expanded */}
      <section className="bg-[#152219] py-14 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23E4C892' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4z'/%3E%3C/g%3E%3C/svg%3E")` }} />
        <div className="relative max-w-[1180px] mx-auto px-6 lg:px-8">
          <div className="mono text-[11px] tracking-[0.18em] uppercase text-[#E4C892]">Belgrove Homes & Properties Limited — Land. Value. Legacy.</div>
          <h2 className="fraunces text-[30px] leading-[1.05] text-[#F7F2E7] mt-3">Begin with a quiet welcome at Belgrove.</h2>
          <p className="public text-[13px] leading-[1.6] text-[#B9C7BB] mt-3 max-w-[56ch] mx-auto">Where trust is titled, warmth is standard, and your tomorrow has ground to stand on. Your named adviser is ready — no queue, no script, just a conversation about what you want to build.</p>
          <Link href="/book-inspection" className="public inline-block mt-6 bg-[#C79A46] text-[#152219] px-8 py-3.5 rounded-[2px] font-semibold hover:bg-[#E4C892] transition-colors shadow-[0_8px_24px_rgba(199,154,70,0.28)]">Book site inspection — Your ground awaits</Link>
          <div className="fraunces italic text-[#E4C892] text-[14px] mt-6">The ground for your future — Where honest investment begins.</div>
        </div>
      </section>
    </div>
  );
}
