"use client";

import { useState } from "react";
import { galleryItems, galleryCategories } from "@/lib/content";

export default function GalleryGrid() {
  const [category, setCategory] = useState<(typeof galleryCategories)[number]>("All");

  const filtered =
    category === "All" ? galleryItems : galleryItems.filter((item) => item.category === category);

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-10">
        {galleryCategories.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`text-sm px-4 py-2 rounded-full border transition-colors ${
              category === cat
                ? "bg-stone-800 text-white border-stone-800"
                : "border-stone-300 text-stone-600 hover:border-stone-500"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="aspect-square bg-stone-200 rounded-lg flex items-end p-4"
          >
            <div>
              <p className="text-xs uppercase tracking-wide text-stone-500">{item.category}</p>
              <p className="text-sm text-stone-700">{item.title}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
