import GalleryGrid from "./GalleryGrid";

export default function GalleryPage() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-20">
      <p className="uppercase tracking-widest text-stone-400 text-xs mb-4">Gallery</p>
      <h1 className="font-serif text-3xl md:text-4xl text-stone-800 mb-12">
        Properties &amp; projects
      </h1>
      <GalleryGrid />
    </div>
  );
}
