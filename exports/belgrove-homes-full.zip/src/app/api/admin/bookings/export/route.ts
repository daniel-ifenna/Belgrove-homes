import { NextRequest, NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { isInternalRole } from "@/lib/authz";
import { allStatuses, allTemperatures } from "@/lib/booking-ui";
import type { Prisma, BookingStatus, LeadTemperature } from "@/generated/prisma/client";

const COLUMNS = [
  { key: "id", header: "ID" },
  { key: "ref", header: "Reference" },
  { key: "name", header: "Name" },
  { key: "email", header: "Email" },
  { key: "preferredDate", header: "Preferred Date" },
  { key: "preferredTime", header: "Preferred Time" },
  { key: "location", header: "Location" },
  { key: "agentName", header: "Agent (site form)" },
  { key: "companyAgent", header: "Company Agent" },
  { key: "companyAgentEmail", header: "Agent Email" },
  { key: "companyAgentPhone", header: "Agent Phone" },
  { key: "companyAgentCategory", header: "Agent Category" },
  { key: "status", header: "Status" },
  { key: "assignedTo", header: "Assigned To" },
  { key: "internalNote", header: "Internal Note" },
  { key: "rescheduledDate", header: "Rescheduled Date" },
  { key: "rescheduledTime", header: "Rescheduled Time" },
  { key: "outcome", header: "Outcome" },
  { key: "leadTemperature", header: "Lead Temperature" },
  { key: "createdAt", header: "Created At" },
  { key: "updatedAt", header: "Updated At" },
  { key: "reviewedBy", header: "Reviewed By" },
  { key: "reviewedAt", header: "Reviewed At" },
] as const;

function fmt(v: unknown): string {
  if (v == null) return "";
  if (v instanceof Date) return v.toISOString();
  return String(v);
}

// CSV has no cell-type metadata, so spreadsheet apps guess a cell's type
// from its leading character on open/import — a value starting with
// =, +, -, or @ gets executed as a formula ("CSV injection"). Free text
// here (name, location, internalNote, agentName) is visitor/admin-supplied,
// so neutralize that before it ever reaches a cell. (The .xlsx path is
// unaffected — exceljs stores cell.value as a typed string, never a
// formula, unless a {formula: ...} object is explicitly passed.)
function sanitizeCsvCell(v: string): string {
  return /^[=+\-@]/.test(v) ? `'${v}` : v;
}

function csvEscape(v: string): string {
  const safe = sanitizeCsvCell(v);
  if (/[",\n]/.test(safe)) return `"${safe.replace(/"/g, '""')}"`;
  return safe;
}

export async function GET(request: NextRequest) {
  const session = await auth();
  if (!isInternalRole(session?.user?.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const params = request.nextUrl.searchParams;

  const where: Prisma.InspectionBookingWhereInput = {};
  const status = params.get("status");
  const leadTemperature = params.get("leadTemperature");
  const agent = params.get("agent");
  const missingAgent = params.get("missingAgent");
  const dateFrom = params.get("dateFrom");
  const dateTo = params.get("dateTo");
  const format = params.get("format") === "xlsx" ? "xlsx" : "csv";

  if (status && (allStatuses as readonly string[]).includes(status)) {
    where.status = status as BookingStatus;
  }
  if (leadTemperature && (allTemperatures as readonly string[]).includes(leadTemperature)) {
    where.leadTemperature = leadTemperature as LeadTemperature;
  }
  if (missingAgent === "1") where.agentId = null;
  else if (agent) {
    // Search both free-text agentName and assigned company agent name/email
    where.OR = [
      { agentName: { contains: agent, mode: "insensitive" } },
      { agent: { name: { contains: agent, mode: "insensitive" } } },
      { agent: { email: { contains: agent, mode: "insensitive" } } },
    ];
  }

  const from = dateFrom ? new Date(dateFrom) : null;
  const to = dateTo ? new Date(dateTo) : null;
  if ((from && Number.isNaN(from.getTime())) || (to && Number.isNaN(to.getTime()))) {
    return NextResponse.json({ error: "Invalid dateFrom/dateTo" }, { status: 400 });
  }
  if (from || to) {
    where.preferredDate = {
      ...(from ? { gte: from } : {}),
      ...(to ? { lte: to } : {}),
    };
  }

  const bookings = await prisma.inspectionBooking.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { assignedToUser: true, reviewedByUser: true, agent: true },
  });

  const rows = bookings.map((b) => ({
    id: b.id,
    ref: b.ref,
    name: b.name,
    email: b.email,
    preferredDate: fmt(b.preferredDate),
    preferredTime: b.preferredTime,
    location: b.location,
    agentName: b.agentName ?? "",
    companyAgent: b.agent?.name ?? "",
    companyAgentEmail: b.agent?.email ?? "",
    companyAgentPhone: b.agent?.phone ?? "",
    companyAgentCategory: b.agent?.category ?? "",
    status: b.status,
    assignedTo: b.assignedToUser?.name ?? "",
    internalNote: b.internalNote ?? "",
    rescheduledDate: fmt(b.rescheduledDate),
    rescheduledTime: b.rescheduledTime ?? "",
    outcome: b.outcome ?? "",
    leadTemperature: b.leadTemperature,
    createdAt: fmt(b.createdAt),
    updatedAt: fmt(b.updatedAt),
    reviewedBy: b.reviewedByUser?.name ?? "",
    reviewedAt: fmt(b.reviewedAt),
  }));

  const filename = `inspection-bookings-${new Date().toISOString().split("T")[0]}`;

  if (format === "xlsx") {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Bookings");
    sheet.columns = COLUMNS.map((c) => ({ header: c.header, key: c.key, width: 20 }));
    sheet.addRows(rows);
    sheet.getRow(1).font = { bold: true };

    const buffer = await workbook.xlsx.writeBuffer();
    return new NextResponse(new Uint8Array(buffer as ArrayBuffer), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}.xlsx"`,
      },
    });
  }

  const header = COLUMNS.map((c) => csvEscape(c.header)).join(",");
  const body = rows
    .map((row) => COLUMNS.map((c) => csvEscape(fmt(row[c.key as keyof typeof row]))).join(","))
    .join("\n");
  const csv = `${header}\n${body}\n`;

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="${filename}.csv"`,
    },
  });
}
