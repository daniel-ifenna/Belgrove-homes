import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { bookingActionSchema } from "@/lib/validation";
import { isTransitionAllowed, actionLabels, isEscalation } from "@/lib/booking-transitions";
import { isInternalRole } from "@/lib/authz";
import type { EmailResult } from "@/lib/email/sendEmail";
import type { InspectionBooking, BookingStatus } from "@/generated/prisma/client";
import {
  sendBookingApproved,
  sendBookingRescheduled,
  sendBookingStatusEmail,
  sendSaleConfirmation,
  sendAgentAssignment,
} from "@/lib/email/emailService";

export async function PATCH(
  request: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!isInternalRole(session?.user?.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const actorId = session!.user.id;
  const actorName = session!.user.name ?? session!.user.email ?? "Unknown";

  const { id } = await ctx.params;
  const body = await request.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const parsed = bookingActionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", issues: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const booking = await prisma.inspectionBooking.findUnique({ where: { id } });
  if (!booking) {
    return NextResponse.json({ error: "Booking not found" }, { status: 404 });
  }

  const input = parsed.data;

  // Optimistic concurrency: if the client's copy is stale, refuse the write
  // rather than silently overwriting whatever another admin just did.
  // Allow 1s tolerance for clock/serialization skew (ISO ms truncation, PG microsecond rounding).
  if (input.expectedUpdatedAt) {
    const expectedMs = new Date(input.expectedUpdatedAt).getTime();
    if (Number.isNaN(expectedMs)) {
      return NextResponse.json({ error: "Invalid expectedUpdatedAt" }, { status: 400 });
    }
    const currentMs = booking.updatedAt.getTime();
    if (Math.abs(expectedMs - currentMs) > 1000) {
      return NextResponse.json(
        {
          error: "This booking was updated by someone else since you loaded it. Refresh and try again.",
          booking,
        },
        { status: 409 }
      );
    }
  }

  // Server-side state machine enforcement — the UI hides invalid actions,
  // but the API is the actual source of truth (raw requests, stale tabs,
  // races between two admins must not be able to corrupt the lifecycle).
  if (!isTransitionAllowed(input.action, booking.status)) {
    return NextResponse.json(
      {
        error: `"${actionLabels[input.action]}" isn't valid from status "${booking.status}".`,
      },
      { status: 409 }
    );
  }

  let updated: InspectionBooking;
  let note: string | null = null;
  let emailResult: EmailResult = { sent: false, error: null };
  let emailAttempted = false;
  const fromStatus: BookingStatus = booking.status;

  switch (input.action) {
    case "approve": {
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: { status: "approved", reviewedById: actorId, reviewedAt: new Date() },
      });
      // If this booking was previously rescheduled, "approve" confirms the
      // rescheduled date/time — not the stale original request.
      const confirmedDate = updated.rescheduledDate ?? updated.preferredDate;
      const confirmedTime = updated.rescheduledTime ?? updated.preferredTime;
      emailResult = await sendBookingApproved(updated.email, {
        ...updated,
        preferredDate: confirmedDate,
        preferredTime: confirmedTime,
      });
      emailAttempted = true;
      note = input.note || null;
      break;
    }

    case "reschedule": {
      const rescheduledDate = new Date(input.rescheduledDate);
      if (Number.isNaN(rescheduledDate.getTime())) {
        return NextResponse.json({ error: "Invalid rescheduled date" }, { status: 400 });
      }
      // Rescheduled date must not be in the past (date-only comparison, time slot defines hour)
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const resDay = new Date(rescheduledDate);
      resDay.setHours(0, 0, 0, 0);
      if (resDay.getTime() < today.getTime()) {
        return NextResponse.json({ error: "Rescheduled date cannot be in the past" }, { status: 400 });
      }
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: {
          status: "rescheduled",
          rescheduledDate,
          rescheduledTime: input.rescheduledTime,
          reviewedById: actorId,
          reviewedAt: new Date(),
        },
      });
      note = `New time: ${rescheduledDate.toDateString()} at ${input.rescheduledTime}`;
      if (input.note) note += ` — ${input.note}`;
      emailResult = await sendBookingRescheduled(updated.email, {
        name: updated.name,
        ref: updated.ref,
        rescheduledDate: updated.rescheduledDate!,
        rescheduledTime: updated.rescheduledTime!,
        location: updated.location,
      });
      emailAttempted = true;
      break;
    }

    case "hold": {
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: { status: "on_hold", reviewedById: actorId, reviewedAt: new Date() },
      });
      emailResult = await sendBookingStatusEmail(updated.email, updated, "on_hold");
      emailAttempted = true;
      note = input.note || null;
      break;
    }

    case "under_review": {
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: {
          status: "under_review",
          reviewedById: actorId,
          reviewedAt: new Date(),
          ...(input.assignedToId !== undefined ? { assignedToId: input.assignedToId } : {}),
        },
      });
      if (input.assignedToId !== undefined) {
        note = input.assignedToId ? "Reassigned" : "Unassigned";
      }
      if (input.note) note = note ? `${note} — ${input.note}` : input.note;
      emailResult = await sendBookingStatusEmail(updated.email, updated, "under_review");
      emailAttempted = true;
      break;
    }

    case "mark_active": {
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: { status: "active", internalNote: input.internalNote },
      });
      note = input.internalNote;
      // Internal-use only per spec — no visitor email for this transition.
      break;
    }

    case "record_outcome": {
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: {
          status: "closed",
          outcome: input.outcome,
          leadTemperature: input.outcome === "not_sold" ? "warm" : booking.leadTemperature,
        },
      });
      note = input.outcome === "sold" ? "Sold" : "Not sold — kept warm for follow-up";
      if (input.note) note += ` — ${input.note}`;
      if (input.outcome === "sold") {
        emailResult = await sendSaleConfirmation(updated.email, updated);
        emailAttempted = true;
      }
      break;
    }

    case "save": {
      const changes: string[] = [];
      if (input.agentName !== undefined && input.agentName !== (booking.agentName ?? "")) {
        changes.push(`agent → ${input.agentName || "(cleared)"}`);
      }
      if (input.internalNote !== undefined && input.internalNote !== (booking.internalNote ?? "")) {
        changes.push("internal note updated");
      }
      if (input.assignedToId !== undefined && input.assignedToId !== booking.assignedToId) {
        changes.push(input.assignedToId ? "reassigned" : "unassigned");
      }
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: {
          ...(input.agentName !== undefined ? { agentName: input.agentName || null } : {}),
          ...(input.internalNote !== undefined ? { internalNote: input.internalNote } : {}),
          ...(input.assignedToId !== undefined ? { assignedToId: input.assignedToId } : {}),
        },
      });
      note = changes.length > 0 ? changes.join("; ") : null;
      break;
    }

    case "escalate_lead": {
      // Enforced here, not just hidden in the UI — a raw request can't use
      // this action to cool a lead off, only to raise it.
      if (!isEscalation(booking.leadTemperature, input.leadTemperature)) {
        return NextResponse.json(
          {
            error: `Can't change lead temperature from "${booking.leadTemperature}" to "${input.leadTemperature}" — this action only escalates.`,
          },
          { status: 400 }
        );
      }
      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: { leadTemperature: input.leadTemperature },
      });
      note = `${booking.leadTemperature} → ${input.leadTemperature}`;
      if (input.note) note += ` — ${input.note}`;
      break;
    }

    case "assign_agent": {
      if (input.agentId === null) {
        // Unassign
        const prevAgent = booking.agentId ? await prisma.agent.findUnique({ where: { id: booking.agentId } }) : null;
        updated = await prisma.inspectionBooking.update({
          where: { id },
          data: { agentId: null, agentName: null },
        });
        note = prevAgent ? `Unassigned from ${prevAgent.name}` : "Unassigned agent";
        if (input.note) note += ` — ${input.note}`;
        break;
      }

      const agent = await prisma.agent.findUnique({ where: { id: input.agentId } });
      if (!agent) {
        return NextResponse.json({ error: "Agent not found" }, { status: 404 });
      }
      if (!agent.isActive) {
        return NextResponse.json({ error: "Agent is deactivated" }, { status: 400 });
      }

      updated = await prisma.inspectionBooking.update({
        where: { id },
        data: { agentId: agent.id, agentName: agent.name },
      });

      // Notify agent via email with client info for follow-up
      emailResult = await sendAgentAssignment(agent.email, {
        agentName: agent.name,
        clientName: updated.name,
        clientEmail: updated.email,
        clientPhone: updated.phone,
        ref: updated.ref,
        preferredDate: updated.preferredDate,
        preferredTime: updated.preferredTime,
        rescheduledDate: updated.rescheduledDate,
        rescheduledTime: updated.rescheduledTime,
        location: updated.location,
        agentCategory: agent.category,
      });
      emailAttempted = true;

      note = `Assigned to ${agent.name} (${agent.category.replace("_", " ")})`;
      if (input.note) note += ` — ${input.note}`;
      break;
    }
  }

  await prisma.bookingActivity.create({
    data: {
      bookingId: id,
      actorId,
      actorName,
      action: input.action,
      fromStatus,
      toStatus: updated.status,
      note,
      emailSent: emailAttempted ? emailResult.sent : null,
      emailError: emailResult.error,
    },
  });

  return NextResponse.json({ booking: updated, emailResult });
}
