import AdminTopBar from "@/components/admin/AdminTopBar";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-stone-50">
      <AdminTopBar />
      <main className="flex-1">{children}</main>
    </div>
  );
}
