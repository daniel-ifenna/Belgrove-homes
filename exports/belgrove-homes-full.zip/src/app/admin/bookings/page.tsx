import Link from "next/link";
import { prisma } from "@/lib/prisma";
import type { Prisma, BookingStatus, LeadTemperature } from "@/generated/prisma/client";
import { allStatuses, allTemperatures, statusColors, statusLabels, temperatureColors, formatDate } from "@/lib/booking-ui";
import AgentNameCell from "./AgentNameCell";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 50;

type SearchParams = {
  status?: string;
  leadTemperature?: string;
  missingAgent?: string;
  page?: string;
};

export default async function AdminBookingsPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number(params.page) || 1);

  const where: Prisma.InspectionBookingWhereInput = {};
  if (params.status && (allStatuses as readonly string[]).includes(params.status)) {
    where.status = params.status as BookingStatus;
  }
  if (
    params.leadTemperature &&
    (allTemperatures as readonly string[]).includes(params.leadTemperature)
  ) {
    where.leadTemperature = params.leadTemperature as LeadTemperature;
  }
  // "Missing agent" now means no company agent assigned (agentId null) — these are the bookings an admin needs to triage.
  // Keeps backward compat for old data where agentName was the only signal: also covers agentName null.
  if (params.missingAgent === "1") {
    where.OR = [{ agentId: null }, { agent: null }];
    // Equivalent to agentId null; Prisma OR with single condition is same as { agentId: null }
    // but we also keep agentName tally visible — unassigned means agent relation missing.
    where.agentId = null;
    delete (where as Record<string, unknown>).OR;
  }

  const [bookings, total, allAgents] = await Promise.all([
    prisma.inspectionBooking.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      include: { agent: true },
    }),
    prisma.inspectionBooking.count({ where }),
    prisma.agent.findMany({ where: { isActive: true }, select: { name: true, category: true } }),
  ]);

  // Token-aware tally (first name / surname) — matches BookingForm logic
  function isTallyMatch(input: string, dbName: string): boolean {
    const q = input.trim().toLowerCase();
    const n = dbName.toLowerCase();
    if (n.includes(q)) return true;
    const qTokens = q.split(/\s+/).filter(Boolean);
    const nTokens = n.split(/\s+/).filter(Boolean);
    return qTokens.some((qt) => nTokens.some((nt) => nt === qt || (qt.length >= 3 && nt.includes(qt))));
  }

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function buildQuery(overrides: Partial<SearchParams>) {
    const merged = { ...params, ...overrides };
    const qs = new URLSearchParams();
    if (merged.status) qs.set("status", merged.status);
    if (merged.leadTemperature) qs.set("leadTemperature", merged.leadTemperature);
    if (merged.missingAgent) qs.set("missingAgent", merged.missingAgent);
    if (merged.page && merged.page !== "1") qs.set("page", merged.page);
    const str = qs.toString();
    return str ? `?${str}` : "";
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-serif text-2xl text-stone-800">Inspection Bookings</h1>
        <a
          href={`/api/admin/bookings/export${buildQuery({ page: undefined })}`}
          className="text-sm border border-stone-300 rounded px-4 py-2 hover:bg-stone-100"
        >
          Export CSV
        </a>
      </div>

      <form className="flex flex-wrap gap-3 mb-6" action="/admin/bookings" method="get">
        <select
          name="status"
          defaultValue={params.status ?? ""}
          className="border border-stone-300 rounded px-3 py-2 text-sm bg-white"
        >
          <option value="">All statuses</option>
          {allStatuses.map((s) => (
            <option key={s} value={s}>
              {statusLabels[s]}
            </option>
          ))}
        </select>

        <select
          name="leadTemperature"
          defaultValue={params.leadTemperature ?? ""}
          className="border border-stone-300 rounded px-3 py-2 text-sm bg-white"
        >
          <option value="">All temperatures</option>
          {allTemperatures.map((t) => (
            <option key={t} value={t}>
              {t[0].toUpperCase() + t.slice(1)}
            </option>
          ))}
        </select>

        <label className="flex items-center gap-2 text-sm border border-stone-300 rounded px-3 py-2 bg-white">
          <input
            type="checkbox"
            name="missingAgent"
            value="1"
            defaultChecked={params.missingAgent === "1"}
          />
          Missing agent
        </label>

        <button type="submit" className="text-sm bg-stone-800 text-white rounded px-4 py-2">
          Filter
        </button>
        {(params.status || params.leadTemperature || params.missingAgent) && (
          <Link href="/admin/bookings" className="text-sm text-stone-500 self-center underline">
            Clear
          </Link>
        )}
      </form>

      <div className="bg-white border border-stone-200 rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-stone-200 text-left text-stone-500">
              <th className="px-4 py-3 font-medium">Ref</th>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Date &amp; time</th>
              <th className="px-4 py-3 font-medium">Location</th>
              <th className="px-4 py-3 font-medium">Agent</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Lead</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.id} className="border-b border-stone-100 last:border-0 hover:bg-stone-50">
                <td className="px-4 py-3 font-mono text-xs">
                  <Link href={`/admin/bookings/${b.id}`} className="text-stone-800 hover:underline">
                    {b.ref}
                  </Link>
                </td>
                <td className="px-4 py-3">{b.name}</td>
                <td className="px-4 py-3 text-stone-500">
                  {b.rescheduledDate ? (
                    <>
                      <div>
                        {formatDate(b.rescheduledDate)} at {b.rescheduledTime}
                      </div>
                      <div className="text-xs text-purple-600">rescheduled</div>
                    </>
                  ) : (
                    <div>
                      {formatDate(b.preferredDate)} at {b.preferredTime}
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 text-stone-500 max-w-[200px] truncate">{b.location}</td>
                <td className="px-4 py-3">
                  {(b as unknown as { agent: { name: string; category: string; email: string } | null }).agent ? (
                    (() => {
                      const ag = (b as unknown as { agent: { name: string; category: string; email: string } | null }).agent!;
                      return (
                        <div className="flex flex-col gap-1">
                          <span className="font-medium text-stone-800">{ag.name}</span>
                          <span className={`inline-flex w-fit px-2 py-0.5 rounded-full text-[10px] ${ag.category === "staff" ? "bg-stone-800 text-white" : "bg-amber-100 text-amber-800"}`}>
                            {ag.category === "hire_purchase" ? "Hire Purchase" : "Staff"} · Company
                          </span>
                        </div>
                      );
                    })()
                  ) : b.agentName ? (
                    (() => {
                      const hit = allAgents.find((a) => isTallyMatch(b.agentName!, a.name));
                      const match = hit?.category ?? null;
                      return (
                        <div className="flex flex-col gap-1">
                          <AgentNameCell bookingId={b.id} initialValue={b.agentName} updatedAt={b.updatedAt} />
                          {match ? (
                            <span className={`inline-flex w-fit px-2 py-0.5 rounded-full text-[10px] ${match === "staff" ? "bg-stone-100 text-stone-700 border border-stone-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
                              ✓ Agent name matches that of DB: {hit!.name} — {match === "hire_purchase" ? "Hire Purchase" : "Staff"}
                            </span>
                          ) : (
                            <span className="inline-flex w-fit px-2 py-0.5 rounded-full text-[10px] bg-red-50 text-red-600 border border-red-200">Not in company DB — external</span>
                          )}
                        </div>
                      );
                    })()
                  ) : (
                    <div className="flex flex-col gap-1">
                      <AgentNameCell bookingId={b.id} initialValue={b.agentName} updatedAt={b.updatedAt} />
                      <span className="text-xs text-stone-400 italic">Unassigned — <Link href={`/admin/bookings/${b.id}`} className="underline text-stone-600">assign</Link></span>
                    </div>
                  )}
                </td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded-full text-xs ${statusColors[b.status]}`}>
                    {statusLabels[b.status]}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${temperatureColors[b.leadTemperature]}`}
                  >
                    {b.leadTemperature}
                  </span>
                </td>
              </tr>
            ))}
            {bookings.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-stone-400">
                  No bookings match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 text-sm text-stone-500">
          <span>
            Page {page} of {totalPages} &middot; {total} bookings
          </span>
          <div className="flex gap-2">
            {page > 1 && (
              <Link
                href={`/admin/bookings${buildQuery({ page: String(page - 1) })}`}
                className="border border-stone-300 rounded px-3 py-1 hover:bg-stone-100"
              >
                Previous
              </Link>
            )}
            {page < totalPages && (
              <Link
                href={`/admin/bookings${buildQuery({ page: String(page + 1) })}`}
                className="border border-stone-300 rounded px-3 py-1 hover:bg-stone-100"
              >
                Next
              </Link>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
