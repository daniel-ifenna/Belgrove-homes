import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";
import { statusColors, statusLabels, temperatureColors, formatDate, formatDateTime } from "@/lib/booking-ui";
import BookingActions from "./BookingActions";
import ActivityTimeline from "./ActivityTimeline";

export default async function AdminBookingDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const [booking, staffUsers, agents, activities, messages] = await Promise.all([
    prisma.inspectionBooking.findUnique({
      where: { id },
      include: { assignedToUser: true, reviewedByUser: true, agent: true },
    }),
    prisma.user.findMany({
      where: { role: { in: ["admin", "staff"] } },
      select: { id: true, name: true, email: true },
      orderBy: { name: "asc" },
    }),
    prisma.agent.findMany({
      where: { isActive: true },
      select: { id: true, name: true, email: true, phone: true, category: true },
      orderBy: [{ category: "asc" }, { name: "asc" }],
    }),
    prisma.bookingActivity.findMany({
      where: { bookingId: id },
      orderBy: { createdAt: "desc" },
    }),
    prisma.bookingMessage.findMany({
      where: { bookingId: id },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  if (!booking) notFound();

  const allAgentsForTally = await prisma.agent.findMany({ select: { name: true, category: true } });
  // Token-aware tally for site form (first name / surname substring) to match BookingForm behavior
  function isTallyMatch(input: string, dbName: string): boolean {
    const q = input.trim().toLowerCase();
    const n = dbName.toLowerCase();
    if (n.includes(q)) return true;
    const qTokens = q.split(/\s+/);
    const nTokens = n.split(/\s+/);
    return qTokens.some((qt) => nTokens.some((nt) => nt === qt || (qt.length >= 3 && nt.includes(qt))));
  }
  // If company agent already assigned, site form value is synced — show as matched to assigned agent.
  // Otherwise, search DB by first name / surname tokens for tally.
  const visitorAgentTally = booking.agent
    ? booking.agent.category
    : booking.agentName
      ? (() => {
          const hit = allAgentsForTally.find((a) => isTallyMatch(booking.agentName!, a.name));
          return hit?.category ?? null;
        })()
      : null;

  const pipeline = ["new", "under_review", "approved", "active", "closed"] as const;
  const currentIdx = pipeline.indexOf(booking.status as (typeof pipeline)[number]);
  const isClosed = booking.status === "closed";

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-stone-500 mb-4">
        <Link href="/admin/bookings" className="hover:text-stone-800 hover:underline">
          ← Bookings
        </Link>
        <span className="text-stone-300">/</span>
        <span className="text-stone-800 font-medium">{booking.ref}</span>
        <span className="text-stone-300">·</span>
        <span className="text-stone-400">{booking.name}</span>
      </div>

      {/* Header — professional */}
      <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="font-serif text-2xl font-medium text-stone-800 tracking-tight">{booking.ref}</h1>
              <span className="font-mono text-xs text-stone-400 border border-stone-200 rounded px-2 py-1">{booking.id.slice(0, 8)}</span>
            </div>
            <p className="text-stone-600 mt-1">
              <span className="font-medium text-stone-800">{booking.name}</span>
              <span className="text-stone-400"> · </span>
              <a href={`mailto:${booking.email}`} className="text-stone-500 hover:text-stone-800 underline decoration-stone-300">
                {booking.email}
              </a>
              {booking.phone && (
                <>
                  <span className="text-stone-300"> · </span>
                  <a href={`tel:${booking.phone}`} className="text-stone-500 hover:text-stone-800">
                    {booking.phone}
                  </a>
                </>
              )}
            </p>
            <p className="text-xs text-stone-400 mt-1">
              Submitted {formatDateTime(booking.createdAt)} · Updated {formatDateTime(booking.updatedAt)}
              {booking.reviewedByUser && <> · Reviewed by {booking.reviewedByUser.name}</>}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className={`px-3 py-1.5 rounded-full text-xs font-medium border ${statusColors[booking.status]} border-transparent`}>{statusLabels[booking.status]}</span>
            <span className={`px-3 py-1.5 rounded-full text-xs font-medium border ${temperatureColors[booking.leadTemperature]} border-transparent`}>Lead: {booking.leadTemperature}</span>
            {booking.agent && (
              <span className={`px-3 py-1.5 rounded-full text-xs font-medium ${booking.agent.category === "staff" ? "bg-stone-800 text-white" : "bg-amber-100 text-amber-800 border border-amber-200"}`}>
                {booking.agent.category === "hire_purchase" ? "Hire Purchase" : "Staff"} · {booking.agent.name}
              </span>
            )}
            {booking.outcome && (
              <span className={`px-3 py-1.5 rounded-full text-xs font-medium ${booking.outcome === "sold" ? "bg-emerald-100 text-emerald-800 border border-emerald-200" : "bg-stone-100 text-stone-600 border border-stone-200"}`}>
                {booking.outcome === "sold" ? "Sold" : "Not sold"}
              </span>
            )}
          </div>
        </div>

        {/* Pipeline progress */}
        <div className="mt-6">
          <div className="flex items-center gap-1.5">
            {pipeline.map((step, idx) => {
              const active = idx <= currentIdx && currentIdx !== -1;
              const isCurrent = idx === currentIdx;
              return (
                <div key={step} className="flex items-center gap-1.5 flex-1">
                  <div className={`h-1.5 flex-1 rounded-full ${active ? (isCurrent ? "bg-stone-800" : "bg-emerald-500") : "bg-stone-200"}`} />
                  {idx < pipeline.length - 1 && <div className="h-px w-2 bg-stone-200 hidden md:block" />}
                </div>
              );
            })}
          </div>
          <div className="flex justify-between mt-2 text-[10px] tracking-wide uppercase text-stone-400">
            <span>New</span>
            <span>Review</span>
            <span>Approved</span>
            <span>Active</span>
            <span>Closed</span>
          </div>
        </div>
      </div>

      {/* Booking details — 2-col pro */}
      <div className="mt-6 grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-stone-200 rounded-xl p-6">
          <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2 mb-5">
            <span className="h-6 w-6 rounded bg-stone-800 text-white grid place-items-center text-xs">▦</span>
            Booking Details
            <span className="ml-auto text-xs font-normal text-stone-400">{booking.location}</span>
          </h2>
          <dl className="grid grid-cols-2 gap-x-6 gap-y-4 text-sm">
            <div className="col-span-2 md:col-span-1">
              <dt className="text-xs tracking-wide uppercase text-stone-400">Client</dt>
              <dd className="mt-1 font-medium text-stone-800">{booking.name}</dd>
              <dd className="text-xs text-stone-500">{booking.email} {booking.phone ? `· ${booking.phone}` : ""}</dd>
            </div>
            <div>
              <dt className="text-xs tracking-wide uppercase text-stone-400">Inspection</dt>
              <dd className="mt-1 text-stone-800">{formatDate(booking.preferredDate)} at {booking.preferredTime}</dd>
              <dd className="text-xs text-stone-500">{booking.location}</dd>
              {booking.rescheduledDate && (
                <dd className="mt-1 text-xs text-purple-700 bg-purple-50 border border-purple-200 rounded px-2 py-1 inline-flex">
                  Rescheduled → {formatDate(booking.rescheduledDate)} at {booking.rescheduledTime}
                </dd>
              )}
            </div>
            <div className="col-span-2 border-t border-stone-100 pt-4">
              <dt className="text-xs tracking-wide uppercase text-stone-400">Company Agent (assigned)</dt>
              <dd className="mt-2">
                {booking.agent ? (
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-stone-50 border border-stone-200">
                    <div className="h-9 w-9 rounded-full bg-stone-800 text-white grid place-items-center text-xs font-medium">
                      {booking.agent.name.split(" ").map((s) => s[0]).join("").slice(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-stone-800">{booking.agent.name}</div>
                      <div className="text-xs text-stone-500">{booking.agent.email} · {booking.agent.phone}</div>
                      <span className={`inline-flex mt-1 px-2 py-0.5 rounded-full text-xs ${booking.agent.category === "staff" ? "bg-stone-800 text-white" : "bg-amber-100 text-amber-800 border border-amber-200"}`}>
                        {booking.agent.category === "hire_purchase" ? "Hire Purchase" : "Staff"} · Company DB
                      </span>
                    </div>
                    <span className="text-xs text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-full px-2 py-1">Assigned</span>
                  </div>
                ) : (
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-sm">
                    <span className="text-amber-800 font-medium">Not assigned</span>
                    <span className="text-amber-700"> — use </span>
                    <a href="#assign-agent" className="underline font-medium">Company Agent</a>
                    <span className="text-amber-700"> below to assign. Unassigned bookings appear in </span>
                    <Link href="/admin/bookings?missingAgent=1" className="underline">
                      Missing agent
                    </Link>
                    <span className="text-amber-700"> filter.</span>
                  </div>
                )}
              </dd>
            </div>
            <div className="col-span-2">
              <dt className="text-xs tracking-wide uppercase text-stone-400">Agent (site form) — visitor input</dt>
              <dd className="mt-2">
                {booking.agentName ? (
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-stone-800">{booking.agentName}</span>
                    {visitorAgentTally ? (
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs border ${visitorAgentTally === "staff" ? "bg-stone-100 text-stone-700 border-stone-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>
                        ✓ Matches DB: {visitorAgentTally === "hire_purchase" ? "Hire Purchase" : "Staff"}
                      </span>
                    ) : (
                      <span className="inline-flex px-2 py-0.5 rounded-full text-xs bg-red-50 text-red-600 border border-red-200">Not in company DB — external</span>
                    )}
                  </div>
                ) : (
                  <span className="text-stone-400 italic">None provided — visitor left blank, admin to assign</span>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs tracking-wide uppercase text-stone-400">Assigned to (internal user)</dt>
              <dd className="mt-1 text-stone-800">{booking.assignedToUser?.name ?? <span className="text-stone-400 italic">Unassigned</span>}</dd>
            </div>
            <div>
              <dt className="text-xs tracking-wide uppercase text-stone-400">Lead</dt>
              <dd className="mt-1">
                <span className={`px-2 py-1 rounded-full text-xs ${temperatureColors[booking.leadTemperature]}`}>{booking.leadTemperature}</span>
                <span className="text-xs text-stone-400 ml-2">status: {statusLabels[booking.status]}</span>
              </dd>
            </div>
            {booking.internalNote && (
              <div className="col-span-2">
                <dt className="text-xs tracking-wide uppercase text-stone-400">Internal note</dt>
                <dd className="mt-1 p-3 bg-stone-50 border border-stone-200 rounded-lg text-sm text-stone-700 whitespace-pre-wrap">{booking.internalNote}</dd>
              </div>
            )}
          </dl>
        </div>

        <div className="bg-white border border-stone-200 rounded-xl p-6">
          <h3 className="text-xs tracking-wide uppercase text-stone-400">Quick Stats</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-stone-500">Messages</span>
              <span className="font-medium text-stone-800">{messages.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Activities</span>
              <span className="font-medium text-stone-800">{activities.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Company agents</span>
              <span className="font-medium text-stone-800">{agents.length} active</span>
            </div>
            <div className="pt-3 border-t border-stone-100">
              <div className="text-xs text-stone-400">Ref</div>
              <div className="font-mono text-sm font-medium text-stone-800">{booking.ref}</div>
              <div className="text-xs text-stone-400 mt-1">{booking.phone ?? "No phone"}</div>
            </div>
          </div>
          <div className="mt-6 flex gap-2">
            <Link href="/admin/bookings" className="flex-1 text-center text-sm border border-stone-300 rounded-lg py-2 hover:bg-stone-50">
              Back to bookings
            </Link>
            <Link href="/admin/agents" className="flex-1 text-center text-sm bg-stone-800 text-white rounded-lg py-2 hover:bg-stone-700">
              Manage agents
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <BookingActions booking={booking} staffUsers={staffUsers} agents={agents} initialMessages={messages} isClosed={isClosed} />
      </div>

      <div className="mt-6">
        <ActivityTimeline activities={activities} />
      </div>
    </div>
  );
}
