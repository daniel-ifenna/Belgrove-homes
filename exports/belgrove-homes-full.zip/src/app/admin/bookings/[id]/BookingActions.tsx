"use client";
/* eslint-disable react-hooks/set-state-in-effect -- intentional prop->state sync after router.refresh */

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { isTransitionAllowed, temperatureRank } from "@/lib/booking-transitions";
import { timeSlots } from "@/lib/content";
import type { BookingStatus, LeadTemperature } from "@/generated/prisma/client";

type Booking = {
  id: string;
  status: BookingStatus;
  leadTemperature: LeadTemperature;
  agentName: string | null;
  agentId?: string | null;
  internalNote: string | null;
  assignedToId: string | null;
  updatedAt: Date;
};

type StaffUser = { id: string; name: string; email: string };

type CompanyAgent = { id: string; name: string; email: string; phone: string; category: "staff" | "hire_purchase" };

type EmailResult = { sent: boolean; error: string | null };

type BookingMessage = { id: string; authorName: string; message: string; createdAt: string | Date };

const temperatureOrder: LeadTemperature[] = ["cold", "warm", "hot"];

export default function BookingActions({
  booking,
  staffUsers,
  agents,
  initialMessages = [],
  isClosed = false,
}: {
  booking: Booking;
  staffUsers: StaffUser[];
  agents: CompanyAgent[];
  initialMessages?: BookingMessage[];
  isClosed?: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [lastEmail, setLastEmail] = useState<EmailResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [conflict, setConflict] = useState(false);
  const [expectedUpdatedAt, setExpectedUpdatedAt] = useState(booking.updatedAt.toISOString());

  const [rescheduledDate, setRescheduledDate] = useState("");
  const [rescheduledTime, setRescheduledTime] = useState("");
  const [internalNote, setInternalNote] = useState(booking.internalNote ?? "");
  const [agentName, setAgentName] = useState(booking.agentName ?? "");
  const [assignedToId, setAssignedToId] = useState(booking.assignedToId ?? "");
  const [reviewAssignedToId, setReviewAssignedToId] = useState(booking.assignedToId ?? "");
  const [activeNote, setActiveNote] = useState("");

  // Per-action optional notes — kept separate (not one shared box) so a note
  // typed for one action never accidentally rides along with a different
  // button click.
  const [approveNote, setApproveNote] = useState("");
  const [holdNote, setHoldNote] = useState("");
  const [reviewNote, setReviewNote] = useState("");
  const [rescheduleNote, setRescheduleNote] = useState("");
  const [outcomeNote, setOutcomeNote] = useState("");
  const [escalateNote, setEscalateNote] = useState("");
  const [selectedAgentId, setSelectedAgentId] = useState(booking.agentId ?? "");
  const [assignNote, setAssignNote] = useState("");
  const [messages, setMessages] = useState<BookingMessage[]>(initialMessages);
  const [messageText, setMessageText] = useState("");
  const [messageSending, setMessageSending] = useState(false);
  const [messageError, setMessageError] = useState<string | null>(null);

  // Sync messages when booking changes (e.g., after router.refresh server fetch)
  useEffect(() => {
    setMessages(initialMessages);
  }, [initialMessages]);

  // The server component re-renders BookingActions with a fresh `booking`
  // prop after every router.refresh() — including after another admin's
  // change (surfaced as 409). useEffect syncs local editable fields to the
  // canonical booking when updatedAt changes, avoiding render-time setState
  // anti-pattern and the extra rerender cascade.
  const bookingAgentId = (booking as unknown as { agentId?: string | null }).agentId ?? null;
  const [syncedUpdatedAt, setSyncedUpdatedAt] = useState(booking.updatedAt.toISOString());
  useEffect(() => {
    const fresh = booking.updatedAt.toISOString();
    if (fresh !== syncedUpdatedAt) {
      setSyncedUpdatedAt(fresh);
      setExpectedUpdatedAt(fresh);
      setAgentName(booking.agentName ?? "");
      setInternalNote(booking.internalNote ?? "");
      setAssignedToId(booking.assignedToId ?? "");
      setReviewAssignedToId(booking.assignedToId ?? "");
      setSelectedAgentId(bookingAgentId ?? "");
    }
  }, [booking.updatedAt, booking.agentName, booking.internalNote, booking.assignedToId, bookingAgentId, syncedUpdatedAt]);

  async function run(action: string, payload: Record<string, unknown> = {}) {
    setBusy(action);
    setError(null);
    setConflict(false);
    try {
      const res = await fetch(`/api/admin/bookings/${booking.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, expectedUpdatedAt, ...payload }),
      });
      const data = await res.json();

      if (res.status === 409) {
        setConflict(true);
        setError(data.error ?? "This booking changed elsewhere. Refresh to see the latest.");
        return;
      }
      if (!res.ok) {
        throw new Error(data.error ?? "Action failed");
      }

      setLastEmail(data.emailResult);
      setExpectedUpdatedAt(data.booking.updatedAt);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(null);
    }
  }

  async function sendMessage() {
    if (!messageText.trim() || messageSending) return;
    setMessageSending(true);
    setMessageError(null);
    try {
      const res = await fetch(`/api/admin/bookings/${booking.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: messageText }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to send message");
      setMessages((m) => [...m, data.message]);
      setMessageText("");
      router.refresh();
    } catch (err) {
      setMessageError(err instanceof Error ? err.message : "Failed to send");
    } finally {
      setMessageSending(false);
    }
  }

  const status = booking.status;
  const showReview =
    isTransitionAllowed("approve", status) ||
    isTransitionAllowed("hold", status) ||
    isTransitionAllowed("under_review", status) ||
    isTransitionAllowed("reschedule", status);
  const showMarkActive = isTransitionAllowed("mark_active", status);
  const showOutcome = isTransitionAllowed("record_outcome", status);

  const currentRank = temperatureRank[booking.leadTemperature];
  const escalationTargets = temperatureOrder.filter((t) => temperatureRank[t] > currentRank);

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded px-4 py-3 flex items-center justify-between gap-4">
          <span>{error}</span>
          {conflict && (
            <button
              onClick={() => router.refresh()}
              className="shrink-0 text-xs bg-red-700 text-white rounded px-3 py-1"
            >
              Refresh
            </button>
          )}
        </div>
      )}

      {showReview && (
        <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm space-y-4">
          <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2">
            <span className="h-6 w-6 rounded bg-stone-800 text-white grid place-items-center text-xs">◎</span>
            Review <span className="text-xs font-normal text-stone-400">· approve / hold / reschedule</span>
          </h2>

          {isTransitionAllowed("approve", status) && (
            <div className="flex flex-wrap items-center gap-2">
              <input
                value={approveNote}
                onChange={(e) => setApproveNote(e.target.value)}
                placeholder="Note (optional)"
                className="border border-stone-300 rounded px-2 py-2 text-sm flex-1 min-w-[160px]"
              />
              <button
                onClick={() => run("approve", { note: approveNote || undefined })}
                disabled={busy !== null}
                className="text-sm bg-emerald-700 text-white rounded px-4 py-2 disabled:opacity-50 shrink-0"
              >
                {busy === "approve" ? "Approving…" : "Approve"}
              </button>
            </div>
          )}

          {isTransitionAllowed("hold", status) && (
            <div className="flex flex-wrap items-center gap-2">
              <input
                value={holdNote}
                onChange={(e) => setHoldNote(e.target.value)}
                placeholder="Note (optional)"
                className="border border-stone-300 rounded px-2 py-2 text-sm flex-1 min-w-[160px]"
              />
              <button
                onClick={() => run("hold", { note: holdNote || undefined })}
                disabled={busy !== null}
                className="text-sm bg-orange-600 text-white rounded px-4 py-2 disabled:opacity-50 shrink-0"
              >
                {busy === "hold" ? "Updating…" : "Put on hold"}
              </button>
            </div>
          )}

          {isTransitionAllowed("under_review", status) && (
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={reviewAssignedToId}
                onChange={(e) => setReviewAssignedToId(e.target.value)}
                className="border border-stone-300 rounded px-2 py-2 text-sm"
              >
                <option value="">Unassigned</option>
                {staffUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
              <input
                value={reviewNote}
                onChange={(e) => setReviewNote(e.target.value)}
                placeholder="Note (optional)"
                className="border border-stone-300 rounded px-2 py-2 text-sm flex-1 min-w-[160px]"
              />
              <button
                onClick={() =>
                  run("under_review", {
                    assignedToId: reviewAssignedToId || null,
                    note: reviewNote || undefined,
                  })
                }
                disabled={busy !== null}
                className="text-sm bg-amber-600 text-white rounded px-4 py-2 disabled:opacity-50 shrink-0"
              >
                {busy === "under_review" ? "Updating…" : "Mark under review"}
              </button>
            </div>
          )}

          {isTransitionAllowed("reschedule", status) && (
            <div className="border-t border-stone-100 pt-4">
              <p className="text-xs text-stone-500 mb-2">Reschedule</p>
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="block text-xs text-stone-400 mb-1">New date</label>
                  <input
                    type="date"
                    value={rescheduledDate}
                    onChange={(e) => setRescheduledDate(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                    className="border border-stone-300 rounded px-2 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-stone-400 mb-1">New time</label>
                  <select
                    value={rescheduledTime}
                    onChange={(e) => setRescheduledTime(e.target.value)}
                    className="border border-stone-300 rounded px-2 py-2 text-sm bg-white"
                  >
                    <option value="" disabled>
                      Select a time
                    </option>
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex-1 min-w-[160px]">
                  <label className="block text-xs text-stone-400 mb-1">Note (optional)</label>
                  <input
                    value={rescheduleNote}
                    onChange={(e) => setRescheduleNote(e.target.value)}
                    className="w-full border border-stone-300 rounded px-2 py-2 text-sm"
                  />
                </div>
                <button
                  onClick={() =>
                    run("reschedule", {
                      rescheduledDate,
                      rescheduledTime,
                      note: rescheduleNote || undefined,
                    })
                  }
                  disabled={busy !== null || !rescheduledDate || !rescheduledTime}
                  className="text-sm bg-purple-700 text-white rounded px-4 py-2 disabled:opacity-50"
                >
                  {busy === "reschedule" ? "Rescheduling…" : "Reschedule"}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {showMarkActive && (
        <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
          <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2 mb-4">
            <span className="h-6 w-6 rounded bg-teal-600 text-white grid place-items-center text-xs">✓</span>
            Mark inspection as held
          </h2>
          <textarea
            value={activeNote}
            onChange={(e) => setActiveNote(e.target.value)}
            placeholder="What happened at the inspection session?"
            rows={3}
            className="w-full border border-stone-300 rounded px-3 py-2 text-sm mb-3"
          />
          <button
            onClick={() => run("mark_active", { internalNote: activeNote })}
            disabled={busy !== null || !activeNote.trim()}
            className="text-sm bg-teal-700 text-white rounded px-4 py-2 disabled:opacity-50"
          >
            {busy === "mark_active" ? "Saving…" : "Mark as active"}
          </button>
        </div>
      )}

      {showOutcome && (
        <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
          <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2 mb-4">
            <span className="h-6 w-6 rounded bg-emerald-600 text-white grid place-items-center text-xs">★</span>
            Record sale outcome
          </h2>
          <input
            value={outcomeNote}
            onChange={(e) => setOutcomeNote(e.target.value)}
            placeholder="Note (optional)"
            className="w-full border border-stone-300 rounded px-3 py-2 text-sm mb-3"
          />
          <div className="flex gap-3">
            <button
              onClick={() => run("record_outcome", { outcome: "sold", note: outcomeNote || undefined })}
              disabled={busy !== null}
              className="text-sm bg-emerald-700 text-white rounded px-4 py-2 disabled:opacity-50"
            >
              {busy === "record_outcome" ? "Saving…" : "Sold"}
            </button>
            <button
              onClick={() =>
                run("record_outcome", { outcome: "not_sold", note: outcomeNote || undefined })
              }
              disabled={busy !== null}
              className="text-sm bg-stone-600 text-white rounded px-4 py-2 disabled:opacity-50"
            >
              {busy === "record_outcome" ? "Saving…" : "Not sold"}
            </button>
          </div>
        </div>
      )}

      <div id="assign-agent" className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
        <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2">
          <span className="h-6 w-6 rounded bg-stone-800 text-white grid place-items-center text-xs">◈</span>
          Company Agent
          <span className="text-xs font-normal text-stone-400">· staff / hire-purchase</span>
        </h2>
        <p className="text-xs text-stone-500 mt-1 mb-4">Assign unassigned bookings to a company agent. The agent is emailed client details to follow up. Site-form tally shows match.</p>
        {agents.length === 0 ? (
          <p className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded px-3 py-2">No company agents yet — <a href="/admin/agents" className="underline">add agents</a> first.</p>
        ) : (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={selectedAgentId}
                onChange={(e) => setSelectedAgentId(e.target.value)}
                className="border border-stone-300 rounded px-3 py-2 text-sm bg-white flex-1 min-w-[200px]"
              >
                <option value="">— Unassigned —</option>
                {agents.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name} — {a.category === "hire_purchase" ? "Hire Purchase" : "Staff"} ({a.email})
                  </option>
                ))}
              </select>
              <input
                value={assignNote}
                onChange={(e) => setAssignNote(e.target.value)}
                placeholder="Note to agent (optional)"
                className="border border-stone-300 rounded px-3 py-2 text-sm flex-1 min-w-[160px]"
              />
              <button
                onClick={() => run("assign_agent", { agentId: selectedAgentId || null, note: assignNote || undefined })}
                disabled={busy !== null}
                className="text-sm bg-stone-800 text-white rounded px-4 py-2 disabled:opacity-50 shrink-0"
              >
                {busy === "assign_agent" ? "Assigning…" : selectedAgentId ? "Assign & notify" : "Unassign"}
              </button>
            </div>
            <p className="text-xs text-stone-400 mt-2">Current: <span className="font-medium text-stone-700">{booking.agentName || "None"}</span> {booking.agentId ? <span className="text-emerald-600">· Company agent assigned</span> : <span className="text-amber-600">· Not yet assigned to company DB</span>} — email sent to agent on assign.</p>
          </>
        )}
      </div>

      {/* Messaging System — appears right after assignment, persists until closed */}
      <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2">
            <span className="h-7 w-7 rounded-full bg-stone-800 text-white grid place-items-center text-xs">💬</span>
            Messaging System
            <span className="text-xs font-normal text-stone-500">· follow-up thread</span>
          </h2>
          <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${isClosed ? "bg-stone-200 text-stone-600" : "bg-emerald-100 text-emerald-700 border border-emerald-200"}`}>
            {isClosed ? "Closed — read-only" : `${messages.length} messages`}
          </span>
        </div>
        <p className="text-xs text-stone-500 mb-4">{isClosed ? "Booking is closed — thread is read-only for audit." : "Post contact notes, follow-up reminders, and internal updates. Visible to all admins until booking is closed."}</p>

        {messages.length === 0 ? (
          <div className="py-8 text-center border border-dashed border-stone-200 rounded-xl bg-stone-50/50">
            <p className="text-sm text-stone-500">No messages yet</p>
            <p className="text-xs text-stone-400 mt-1">Start the thread after assigning a company agent.</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
            {messages.map((m) => (
              <div key={m.id} className="flex gap-3 p-3 rounded-xl border border-stone-100 bg-stone-50/60">
                <div className="h-8 w-8 rounded-full bg-stone-800 text-white grid place-items-center text-xs shrink-0 font-medium">
                  {m.authorName
                    .split(" ")
                    .map((s) => s[0])
                    .join("")
                    .slice(0, 2)
                    .toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-sm font-medium text-stone-800">{m.authorName}</span>
                    <span className="text-xs text-stone-400 shrink-0">{new Date(m.createdAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</span>
                  </div>
                  <p className="text-sm text-stone-600 mt-1 whitespace-pre-wrap break-words">{m.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {!isClosed ? (
          <div className="mt-5">
            <textarea
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="e.g. Called client — confirmed Thu 10am, sent pin. Next: dispatch Ada."
              rows={3}
              className="w-full border border-stone-300 rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-stone-400 resize-none"
            />
            <div className="flex items-center justify-between mt-3">
              <span className="text-xs text-stone-400">{messageText.length}/5000</span>
              <button onClick={sendMessage} disabled={!messageText.trim() || messageSending} className="text-sm bg-stone-800 text-white rounded-lg px-5 py-2.5 font-medium hover:bg-stone-700 disabled:opacity-50">
                {messageSending ? "Sending…" : "Send message"}
              </button>
            </div>
            {messageError && <p className="text-xs text-red-600 mt-2">{messageError}</p>}
          </div>
        ) : (
          <div className="mt-5 p-3 bg-stone-100 border border-stone-200 rounded-xl text-xs text-stone-500 text-center">🔒 Closed — messaging is read-only. See timeline for final outcome.</div>
        )}
      </div>

      <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
        <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2 mb-3">
          <span className="h-6 w-6 rounded bg-red-600 text-white grid place-items-center text-xs">◐</span>
          Lead temperature
        </h2>
        <p className="text-sm text-stone-600 mb-3">
          Currently <span className="font-medium capitalize">{booking.leadTemperature}</span>. This can only
          be raised manually — the one automatic downgrade is a &ldquo;not sold&rdquo; outcome
          setting it to warm.
        </p>
        {escalationTargets.length > 0 ? (
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={escalateNote}
              onChange={(e) => setEscalateNote(e.target.value)}
              placeholder="Note (optional)"
              className="border border-stone-300 rounded px-2 py-2 text-sm flex-1 min-w-[160px]"
            />
            {escalationTargets.map((t) => (
              <button
                key={t}
                onClick={() =>
                  run("escalate_lead", { leadTemperature: t, note: escalateNote || undefined })
                }
                disabled={busy !== null}
                className="text-sm bg-red-600 text-white rounded px-4 py-2 disabled:opacity-50 shrink-0"
              >
                {busy === "escalate_lead" ? "Updating…" : `Mark as ${t}`}
              </button>
            ))}
          </div>
        ) : (
          <p className="text-xs text-stone-400">Already at the highest temperature.</p>
        )}
      </div>

      <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
        <h2 className="text-sm font-semibold text-stone-700 flex items-center gap-2 mb-4">
          <span className="h-6 w-6 rounded bg-stone-100 border border-stone-200 grid place-items-center text-xs">✎</span>
          Edit fields
        </h2>
        <div className="grid gap-4">
          <div>
            <label className="block text-xs text-stone-400 mb-1">Agent name</label>
            <input
              value={agentName}
              onChange={(e) => setAgentName(e.target.value)}
              className="w-full border border-stone-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-stone-400 mb-1">Assigned to</label>
            <select
              value={assignedToId}
              onChange={(e) => setAssignedToId(e.target.value)}
              className="w-full border border-stone-300 rounded px-3 py-2 text-sm bg-white"
            >
              <option value="">Unassigned</option>
              {staffUsers.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-stone-400 mb-1">Internal note</label>
            <textarea
              value={internalNote}
              onChange={(e) => setInternalNote(e.target.value)}
              rows={3}
              className="w-full border border-stone-300 rounded px-3 py-2 text-sm"
            />
          </div>
        </div>
        <button
          onClick={() =>
            run("save", { agentName, internalNote, assignedToId: assignedToId || null })
          }
          disabled={busy !== null}
          className="mt-4 text-sm border border-stone-300 rounded px-4 py-2 hover:bg-stone-50 disabled:opacity-50"
        >
          {busy === "save" ? "Saving…" : "Save"}
        </button>
      </div>

      {lastEmail && !conflict && (
        <>
          {lastEmail.sent && <p className="text-xs text-emerald-600">Email sent.</p>}
          {!lastEmail.sent && lastEmail.error && (
            <p className="text-xs text-red-600">Email failed: {lastEmail.error}</p>
          )}
        </>
      )}
    </div>
  );
}
