import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Belgrove Homes",
  description: "Find your next home. Book a property inspection with Belgrove Homes.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">{children}</body>
    </html>
  );
}
