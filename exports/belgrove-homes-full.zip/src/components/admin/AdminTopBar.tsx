"use client";

import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import Link from "next/link";
import NotificationBell from "./NotificationBell";

export default function AdminTopBar() {
  const pathname = usePathname();

  if (pathname === "/admin/login") return null;

  return (
    <header className="border-b border-stone-200 bg-white">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/admin/bookings" className="font-serif text-lg text-stone-800">
          Belgrove Homes <span className="text-stone-400 text-sm font-sans">Admin</span>
        </Link>
        <div className="flex items-center gap-6">
          <nav className="flex items-center gap-4 text-sm">
            <Link
              href="/admin/bookings"
              className={`${pathname?.startsWith("/admin/bookings") ? "text-stone-800 font-medium" : "text-stone-500"} hover:text-stone-800`}
            >
              Bookings
            </Link>
            <Link
              href="/admin/agents"
              className={`${pathname?.startsWith("/admin/agents") ? "text-stone-800 font-medium" : "text-stone-500"} hover:text-stone-800`}
            >
              Agents
            </Link>
          </nav>
          <NotificationBell />
          <button
            onClick={() => signOut({ callbackUrl: "/admin/login" })}
            className="text-sm text-stone-500 hover:text-stone-800"
          >
            Sign out
          </button>
        </div>
      </div>
    </header>
  );
}
