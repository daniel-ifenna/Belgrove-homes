export default function Footer() {
  return (
    <footer className="bg-stone-800 text-stone-300 mt-24">
      <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="font-serif text-lg text-white mb-2">Belgrove Homes</h3>
          <p className="text-sm text-stone-400">
            Guiding buyers and sellers through every stage of the property journey since 2008.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-white mb-2">Contact</h4>
          <p className="text-sm text-stone-400">128 Harbor Ave, Suite 400</p>
          <p className="text-sm text-stone-400">contact@belgrovehomes.example</p>
          <p className="text-sm text-stone-400">(555) 019-4420</p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-white mb-2">Follow</h4>
          <div className="flex gap-4 text-sm text-stone-400">
            <span>Instagram</span>
            <span>LinkedIn</span>
            <span>Facebook</span>
          </div>
        </div>
      </div>
      <div className="border-t border-stone-700 py-4 text-center text-xs text-stone-500">
        &copy; {new Date().getFullYear()} Belgrove Homes. All rights reserved.
      </div>
    </footer>
  );
}
